package Common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class data_from_Excel {
	static FileInputStream fis;
	static HSSFWorkbook workbook;
	static HSSFSheet sheet;

	public static void main(String[] args) throws IOException {
		sdusername();
		// TODO Auto-generated method stub
		
	}

	private static String sdusername() throws IOException {
		fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
		  workbook = new HSSFWorkbook(fis);//C:\Users\radhika.j\eclipse-workspace\SFBG_Project\src\main\java\Common\TestData.xls
		  sheet =workbook.getSheet("Sheet1");
		  String login = sheet.getRow(1).getCell(0).getStringCellValue();
		  System.out.println(login);
		return login;
		
	}

}

package Common;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


public class salesforce extends driver {
	
	public static ExtentTest teststep;
	
	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		salesforcelogin();
		createopportunity();

	}
	public static void salesforcelogin() throws InterruptedException, IOException
	{
		
		teststep = ExtentReport.extent.createTest("Login to salesagent profile");
		
		try {
			
			
			teststep.log(Status.PASS, "logged in to salsagent profile");
			
			 //login into salesforce
			
		     driver.findElement(By.id("username")).sendKeys(Excel.salesdeskusername());
		     driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
		     driver.findElement(By.xpath("//input[@type='submit']")).click();
		     Thread.sleep(5000);
		     
		     
		       
		}catch(Throwable t) {
			teststep.log(Status.FAIL, "Error occured during login page");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Login_failed_"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
				
			
			
			
			teststep.addScreenCaptureFromPath(screenShot);
			//teststep.addScreenCaptureFromPath("path to be provided");
		}
		ExtentReport.extent.flush();
	       
	}
	public static void BcoeLogin() throws IOException
	{
		teststep = ExtentReport.extent.createTest("Login to BCOE profile");
try {
			
			driver.get("https://vmb--vmbuat.my.salesforce.com/");
			teststep.log(Status.PASS, "Logged into BCOE profile");
			
			 //login into salesforce
			
		     driver.findElement(By.id("username")).sendKeys(Excel.Bcoeusername());
		     driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
		     driver.findElement(By.xpath("//input[@type='submit']")).click();
		    
		       
		}catch(Throwable t) {
			teststep.log(Status.FAIL, "Error occured during login page");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\BCOE_login_failed_"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			//teststep.addScreenCaptureFromPath("path to be provided");
		}
		ExtentReport.extent.flush();
	       
	}
	public static void search() throws Exception
	{
		 driver.findElement(By.xpath("//input[@id='phSearchInput']")).sendKeys(Excel.opportunity());
	      driver.findElement(By.id("phSearchButton")).click();
	}
	public static void oppsearch() throws Exception
	{
		 driver.findElement(By.xpath("//input[@id='phSearchInput']")).sendKeys(Excel.opportunity());
	      driver.findElement(By.id("phSearchButton")).click();
	      driver.findElement(By.linkText(Excel.opportunity())).click();
	}
	public static void Bcoe() throws Exception
	{
		teststep = ExtentReport.extent.createTest("quoting autoapproval");
		try {
			teststep.log(Status.PASS, "Quoting auto approval checked");
			salesforce.oppsearch();
		
	     Thread.sleep(5000);
	     driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='edit']")).click();
	     driver.findElement(By.id("00Nb000000ADKJ5")).click();
	     
	     driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='save']")).click();
	     
	     
	     
		}catch(Throwable T) {
			teststep.log(Status.FAIL, "quoting approved");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\quoting_autoapproval failed"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
		}
	}
	public static void leadcreation() throws IOException
	{
		teststep = ExtentReport.extent.createTest("Lead creation");
		try
		{
			teststep.log(Status.PASS, "Successfully created the Lead");
			Thread.sleep(2000);
			 driver.findElement(By.linkText("Leads")).click();
			 driver.findElement(By.name("new")).click();
			 Thread.sleep(5000);
			 driver.findElement(By.xpath("//input[@id='input-0']")).sendKeys(Excel.Leadname());
			 driver.findElement(By.xpath("//button[@class='slds-button slds-button_brand searchCmp']")).click();
			 driver.findElement(By.xpath("//button[@class='slds-button slds-button_neutral createNew']")).click();
			 Thread.sleep(2000);
			driver.findElement(By.id("lea20")).sendKeys("test");
			 WebElement employees = driver.findElement(By.id("00Nb00000039oRi"));
			 Select s = new Select(employees);
			 s.selectByValue("> 249 - MLE");
			 
			 WebElement salutation = driver.findElement(By.id("name_salutationlea2"));
			 Select a = new Select(salutation);
			 a.selectByValue("Mr.");
			 
			 driver.findElement(By.id("name_firstlea2")).sendKeys(Excel.firstname());
			 driver.findElement(By.id("name_lastlea2")).sendKeys(Excel.Lastname());
			 driver.findElement(By.name("lea11")).sendKeys(Excel.email());
			 driver.findElement(By.name("lea8")).sendKeys(Excel.contact());
			 
			 driver.findElement(By.id("lea16street")).sendKeys(Excel.Street());
			 driver.findElement(By.id("lea16city")).sendKeys(Excel.City());
			 driver.findElement(By.id("lea16zip")).sendKeys(Excel.Zipcode());
			 driver.findElement(By.id("lea16country")).sendKeys(Excel.Country());
			
			 
			 Select marketing = new Select(driver.findElement(By.id("00N8E00000Au1ql")));
			 marketing.selectByValue("No");
			 
			 WebElement ppintrest = driver.findElement(By.id("00Nb00000039oRl"));
			 Select b = new Select(ppintrest);
			 b.selectByValue("Broadband");
			 
			 WebElement service = driver.findElement(By.id("00Nb0000009rynb"));
			 Select c = new Select(service);
			 c.selectByValue("Yes");
			 
			WebElement leadsource = driver.findElement(By.id("lea5"));
			Select l = new Select(leadsource);
			l.selectByValue("BD North");
			
		   WebElement leadorigin =	driver.findElement(By.id("00Nb00000039oRd"));
		   Select o = new Select(leadorigin);
		   o.selectByValue("Email");
		   
		   WebElement leadstatus = driver.findElement(By.id("lea13"));
		   Select ls = new Select(leadstatus);
		   ls.selectByValue("Qualified");
		   
		   driver.findElement(By.xpath("//td[@id='topButtonRow']/input[@name='save']")).click();
		   
		}catch(Throwable t) {
			teststep.log(Status.FAIL, "Error occured in lead creation");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\failed_to_createLead"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
		}
		ExtentReport.extent.flush();
	}
	public static void createopportunity() throws IOException
	{
		teststep = ExtentReport.extent.createTest("Opportunity creation");
		try {
			teststep.log(Status.PASS, "Successfully created the opportunity");
			driver.findElement(By.xpath("//a[@title='Opportunities Tab']")).click();
			
			 driver.findElement(By.name("new")).click();
			 
			 driver.findElement(By.id("opp3")).sendKeys(Excel.opportunity());
			 
			 driver.findElement(By.id("opp4")).sendKeys("test.janet");
			 
			 WebElement type = driver.findElement(By.id("opp5"));
			 Select a = new Select(type);
			 a.selectByValue("New");
			 
			 WebElement typedetails = driver.findElement(By.id("00Nb00000039oS4"));
			 Select td = new Select(typedetails);
			 td.selectByValue("New Business");
			 
			 WebElement sales= driver.findElement(By.id("00Nb00000039oS1"));
			 Select b = new Select(sales);
			 b.selectByValue("Telesales");
			 
			 WebElement FA = driver.findElement(By.id("00Nb0000006MHJ7"));
			 Select c = new Select (FA);
			 c.selectByValue("No");
			 
			WebElement productintrest = driver.findElement(By.id("00Nb00000039p5N"));
			Select d = new Select(productintrest);
			d.selectByValue("Broadband");
			
			driver.findElement(By.xpath("//*//table[@id='bodyTable']//tbody//tr//td[2]//form//table[@class='detailList']//tbody//tr//td[4]//div[1]//span//span[@class='dateFormat']//a")).click();
			WebElement stage = driver.findElement(By.id("opp11"));
			Select e = new Select(stage);
			e.selectByValue("Qualified");
			
			WebElement pm = driver.findElement(By.id("00N3z00000CWxyX"));
			Select f = new Select(pm);
			f.selectByValue("No");
			
			driver.findElement(By.id("opp17")).sendKeys("test");
			
			driver.findElement(By.xpath("//input[@value='Save & Add Product']")).click();
			
			
		}catch(Throwable t){
			teststep.log(Status.FAIL, "Error in creating opportunity");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\failed_to_create_opportunity"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
		}
		 ExtentReport.extent.flush();
		
		return;
	}
	public static void addproduct() throws InterruptedException, IOException
	
		{
		teststep = ExtentReport.extent.createTest("Adding Product");
		try {
			teststep.log(Status.PASS, "Successfully Added the Product");
			Thread.sleep(3000);
			driver.findElement(By.id("j_id0:all:j_id41:searchbox")).sendKeys(Excel.product());
			driver.findElement(By.name("j_id0:all:j_id41:search_button")).click();
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//table[@id='prodTable']//tr[1]//td[1]")).click();
			Thread.sleep(2000);
			
			
			
			 WebElement bpt = driver.findElement(By.name("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id109"));
		      Select bp = new Select (bpt);
		      bp.selectByValue("No");
			
			driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id115")).sendKeys("1");
			
			//dates
			WebElement date =driver.findElement(By.xpath("//tbody/tr[13]/td[1]/div[1]/span[1]/span[1]/a[1]"));
			  JavascriptExecutor js = (JavascriptExecutor)driver;
			   	js.executeScript("arguments[0].click()", date);
			Thread.sleep(2000);
		   WebElement ele =driver.findElement(By.xpath("//tbody/tr[14]/td[1]/span[1]/span[1]/a[1]"));
		      JavascriptExecutor js2 = (JavascriptExecutor)driver;
		  	js2.executeScript("arguments[0].click()", ele);
		      
		      Thread.sleep(2000);
		     
		    WebElement ele1=  driver.findElement(By.xpath("//tbody/tr[15]/td[1]/span[1]/span[1]/a[1]"));
		    JavascriptExecutor js1 = (JavascriptExecutor)driver;
			js1.executeScript("arguments[0].click()", ele1);
			Thread.sleep(2000);
			WebElement billing = driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id137"));
			Select bill = new Select (billing);
			bill.selectByValue("Monthly");
			   Thread.sleep(1000);                                          //j_id0:all:selectedproducts:j_id94:0:j_id96:j_id100
			 WebElement type1 = driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id100"));
			 Select ab = new Select(type1);
			 ab.selectByValue("New");
			 Thread.sleep(1000);
			 
			 WebElement typedetails1 = driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id101"));
			 Select td1 = new Select(typedetails1);
			 td1.selectByValue("New Business");
			 
			 Thread.sleep(6000);
			driver.findElement(By.xpath("//input[@id='j_id0:all:selectedproducts:j_id90:saveComeBack']")).click(); 
			
		}catch(Throwable t) {
			teststep.log(Status.FAIL, "Error occured in adding products");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\erroroccured in adding products"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
			
		}
		ExtentReport.extent.flush();	

	}
	public static void converting_lead() throws IOException
	{
		teststep = ExtentReport.extent.createTest("Converting the lead");
		try {
			teststep.log(Status.PASS, "Successfully converted to opportunity");
		  driver.findElement(By.xpath("//td[@id='topButtonRow']/input[@value='Convert']")).click();
			 
			driver.findElement(By.id("j_id0:all:j_id42:j_id43:conv")).click();
	}catch(Throwable t) {
		teststep.log(Status.FAIL, "failed to convert the lead");
		Date today = new Date();
		SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
		String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
		File dir = new File(path1);
		if(!(dir.exists())){
			dir.mkdir();
			
		}
		SimpleDateFormat time = new SimpleDateFormat("hh-mm");
		String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\lead_conversion_failed_"+time.format(today)+".png";

        // Call Webdriver to click the screenshot.
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        // Save the screenshot.
        FileUtils.copyFile(scrFile, new File(screenShot));
		
			
		
		
		
		teststep.addScreenCaptureFromPath(screenShot);
	}
		ExtentReport.extent.flush();	
}
	public static void quoted() throws Exception
	{
		teststep= ExtentReport.extent.createTest("Quoted Stage");
		try {
			teststep.log(Status.PASS, "Opportunity moved upto quoted stage");
			
			 salesforce.oppsearch();
			 Thread.sleep(1000);
			 driver.findElement(By.name("submit")).click();
			 driver.switchTo().alert().accept();
			Thread.sleep(2000);
		}catch(Throwable t) {
			teststep.log(Status.FAIL,"Opportunity failed to move to quoted stage");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\error_in_quoted_stage"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
		}
		ExtentReport.extent.flush();
	}
	public static void awaiting() throws Exception
	{
		teststep= ExtentReport.extent.createTest("awaiting Stage");
		try {
			teststep.log(Status.PASS, "Opportunity moved upto awaiting stage");
			driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='edit']")).click();
			Select stage11= new Select(driver.findElement(By.id("opp11")));
			stage11.selectByValue("Awaiting Contract");
			driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='save']")).click();
			
			Thread.sleep(2000);
			 WebElement frame1 = driver.findElement(By.xpath("//iframe[@id='066b0000001NDxa']"));
		     driver.switchTo().frame(frame1);
			 
			WebElement docname= driver.findElement(By.id("j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_1_j_id11_ilecell"));
			Actions doc = new Actions(driver);
			doc.moveToElement(docname).doubleClick().build().perform();
			Thread.sleep(1000);
			driver.findElement(By.id("j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_1_j_id11")).sendKeys("abc");
			
			WebElement doclink =  driver.findElement(By.id("j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11_ilecell"));
		   Actions doc1 = new Actions(driver);
		   doc1.moveToElement(doclink).doubleClick().build().perform();
		   Thread.sleep(1000);
		  // id="j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11_ilecell" j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11
		   driver.findElement(By.id("j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11")).sendKeys("abc.com");
		   driver.findElement(By.name("j_id0:j_id1:j_id3:j_id4:bottom:j_id5")).click();

		   
			driver.switchTo().defaultContent();
			WebElement payplan = driver.findElement(By.id("00Nb0000003s0T7_chkbox"));
			Actions pp = new Actions (driver);
			pp.moveToElement(payplan).doubleClick().build().perform();
			driver.findElement(By.id("00Nb0000003s0T7")).click();
			driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='inlineEditSave']")).click();
		}catch(Throwable t) {
			teststep.log(Status.FAIL,"Opportunity failed to move to awaiting stage");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Error occured in awaiting stage"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
		}
		ExtentReport.extent.flush();
	}
	public static void submit() throws Exception
	{
		teststep= ExtentReport.extent.createTest("submit Stage");
		try {
			teststep.log(Status.PASS, "Opportunity moved upto Submit stage");
			
			Thread.sleep(3000);
			//WebElement element = driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='edit']"));
			//WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
			Common_functions.edit();
			Thread.sleep(1000);
			Select stage12= new Select(driver.findElement(By.id("opp11")));
			stage12.selectByValue("Submit Contract");
			Thread.sleep(1000);
			Common_functions.save();
			
			Thread.sleep(2000);
		
		}catch(Throwable t) {
			teststep.log(Status.FAIL,"Opportunity failed to move to submit stage");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Error occured in submit stage"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
		}
		ExtentReport.extent.flush();
	}
	public static void salesengagement() throws Exception
	{
		teststep= ExtentReport.extent.createTest("Sales_Engagement");
		try {
			teststep.log(Status.PASS, "Sales Engagement created and completed Successfully");
			Thread.sleep(3000);
			//String submitstatus =driver.findElement(By.id("")).getText();
			
			     ////a[@id='0068E00000SABoz_00Nb0000009Fbzj_link']/span
			driver.findElement(By.xpath("//div[3]/a[5]/span[contains(text(),'Sales Engagements')]")).click();

			driver.findElement(By.xpath("//input[@value='New Sales Engagement']")).click();

			WebElement record = driver.findElement(By.id("p3"));
			Select typeR = new Select(record);
			typeR.selectByValue("012b0000000MAJw");//Business Enablement and Managed Service Desk
			driver.findElement(By.xpath("//input[@value='Continue']")).click();
			
			
			WebElement segroup = driver.findElement(By.id("00Nb0000009Fbzp"));
			Select seG = new Select(segroup);
			seG.selectByValue("Business Enablement Government");
			WebElement frame = driver.findElement(By.xpath("//iframe[@class='cke_wysiwyg_frame cke_reset']"));
			driver.switchTo().frame(frame);
			driver.findElement(By.id("00Nb0000009FbzbEAC_rta_body")).sendKeys("test");
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//td[@id='bottomButtonRow']/input[@name='save']")).click();
			
		    
		     

			
			 String SEname =  driver.findElement(By.id("Name_ilecell")).getText();
		     System.out.println(SEname);
			  
			
			 
			 Common_functions.logout();
			 salesforce.BcoeLogin();
			 salesforce.oppsearch();
			 driver.findElement(By.xpath("//a[5]/span[@class='listTitle']")).click();
				
				driver.findElement(By.linkText(SEname)).click();
				driver.findElement(By.name("edit")).click();
				WebElement ReqStatus = driver.findElement(By.name("00Nb0000009Fbzv"));
				Select r = new Select(ReqStatus);
				r.selectByValue("Completed - Resolved");
				
				driver.findElement(By.xpath("//td[@id='bottomButtonRow']/input[@name='save']")).click();
		    
		     
		     
		}catch(Throwable t) {
			teststep.log(Status.FAIL,"failed to complete sales engagement");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\error in sales Engagement"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
		}
		ExtentReport.extent.flush();
	}
	public static void order_audit() throws Exception
	{
		teststep= ExtentReport.extent.createTest("Order_audit");
		try {
			teststep.log(Status.PASS, "Order Audit checkbox checked successfully");
			salesforce.oppsearch();
			Thread.sleep(2000);
			WebElement orderaudit = driver.findElement(By.id("00Nb0000009scG8_chkbox"));
			Actions order = new Actions(driver);
			order.moveToElement(orderaudit).doubleClick().build().perform();
			driver.findElement(By.id("00Nb0000009scG8")).click();
			driver.findElement(By.xpath("//td[@id='topButtonRow']/input[@name='inlineEditSave']")).click();
		}catch(Throwable t) {
			teststep.log(Status.FAIL,"Failed to order audit complete check box");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\error in order audit approval"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
		}
		ExtentReport.extent.flush();
	}
	public static void SignedContract() throws Exception
	{
		teststep= ExtentReport.extent.createTest("Signed Stage");
		try {
			teststep.log(Status.PASS, "Opportunity moved upto signed contract");
			Common_functions.logout();
			salesforce.salesforcelogin();
			salesforce.oppsearch();
			WebElement status11 = driver.findElement(By.id("opp11_ileinner"));
			Actions st11 = new Actions(driver);
			st11.moveToElement(status11).doubleClick().build().perform();
			WebElement st12 = driver.findElement(By.id("opp11"));
			Select signed = new Select(st12);
			signed.selectByValue("Signed Contract");
			
			driver.findElement(By.xpath("//input[@value='OK']")).click();
			
			
			driver.findElement(By.xpath("//td[@id='topButtonRow']/input[@name='inlineEditSave']")).click();
		Thread.sleep(5000);
			//submitting for approval
			driver.findElement(By.xpath("//input[@value='Submit for Approval']")).click();
			driver.switchTo().alert().accept();
		
		}catch(Throwable t) {
			teststep.log(Status.FAIL,"Failed to move to signed contract");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Error in signed stage"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
		}
		ExtentReport.extent.flush();
	}
}


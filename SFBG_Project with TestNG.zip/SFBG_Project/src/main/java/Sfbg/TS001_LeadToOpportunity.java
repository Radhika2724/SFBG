package Sfbg;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Excel;
import Common.ExtentReport;

public class TS001_LeadToOpportunity {
	@BeforeSuite
	public static void browser() {
		Common.driver.chromebrowser();
	}
	@BeforeTest
	public static void Initializingreport() throws InterruptedException
	{
		Common.ExtentReport.initializereportervariable();
	}
	@Test(priority=0)
	public static void LeadToOpportunity() throws IOException
	{
		
		Common.salesforce.teststep = ExtentReport.extent.createTest("TS001-Lead to Opportunity");
		
		try {
			
			
			Common.salesforce.teststep.log(Status.PASS, "sucessfully converted the lead to opportunity");
			
			Thread.sleep(2000);
			
			//login to salesforce
			 Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.salesdeskusername());
			 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
			 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
		     Thread.sleep(2000);
		     //creating new lead
		     Common.driver.driver.findElement(By.linkText("Leads")).click();
		     Common.driver.driver.findElement(By.name("new")).click();
			 Thread.sleep(5000);
			 Common.driver.driver.findElement(By.xpath("//input[@id='input-0']")).sendKeys(Excel.Leadname());
			 Common.driver.driver.findElement(By.xpath("//button[@class='slds-button slds-button_brand searchCmp']")).click();
			 Common.driver.driver.findElement(By.xpath("//button[@class='slds-button slds-button_neutral createNew']")).click();
			 Thread.sleep(2000);
			 Common.driver.driver.findElement(By.id("lea20")).sendKeys("test");
			 WebElement employees = Common.driver.driver.findElement(By.id("00Nb00000039oRi"));
			 Select s = new Select(employees);
			 s.selectByValue("> 249 - MLE");
			 
			 WebElement salutation = Common.driver.driver.findElement(By.id("name_salutationlea2"));
			 Select a = new Select(salutation);
			 a.selectByValue("Mr.");
			 
			 Common.driver.driver.findElement(By.id("name_firstlea2")).sendKeys(Excel.firstname());
			 Common.driver.driver.findElement(By.id("name_lastlea2")).sendKeys(Excel.Lastname());
			 Common.driver.driver.findElement(By.name("lea11")).sendKeys(Excel.email());
			 Common.driver.driver.findElement(By.name("lea8")).sendKeys(Excel.contact());
			 
			 Common.driver.driver.findElement(By.id("lea16street")).sendKeys(Excel.Street());
			 Common.driver.driver.findElement(By.id("lea16city")).sendKeys(Excel.City());
			 Common.driver.driver.findElement(By.id("lea16zip")).sendKeys(Excel.Zipcode());
			 Common.driver.driver.findElement(By.id("lea16country")).sendKeys(Excel.Country());
			
			 
			 Select marketing = new Select(Common.driver.driver.findElement(By.id("00N8E00000Au1ql")));
			 marketing.selectByValue("No");
			 
			 WebElement ppintrest = Common.driver.driver.findElement(By.id("00Nb00000039oRl"));
			 Select b = new Select(ppintrest);
			 b.selectByValue("Broadband");
			 
			 WebElement service = Common.driver.driver.findElement(By.id("00Nb0000009rynb"));
			 Select c = new Select(service);
			 c.selectByValue("Yes");
			 
			WebElement leadsource = Common.driver.driver.findElement(By.id("lea5"));
			Select l = new Select(leadsource);
			l.selectByValue("BD North");
			
		   WebElement leadorigin =	Common.driver.driver.findElement(By.id("00Nb00000039oRd"));
		   Select o = new Select(leadorigin);
		   o.selectByValue("Email");
		   
		   WebElement leadstatus = Common.driver.driver.findElement(By.id("lea13"));
		   Select ls = new Select(leadstatus);
		   ls.selectByValue("Qualified");
		   
		   Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']/input[@name='save']")).click();
		   
		   //converting lead
		   Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']/input[@value='Convert']")).click();
			 
		   Common.driver.driver.findElement(By.id("j_id0:all:j_id42:j_id43:conv")).click();
		   
		}catch(Throwable t) {
			Common.salesforce.teststep.log(Status.FAIL, "failed to convert the lead to opportunity");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Login_failed_"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
				
			
			
			
			Common.salesforce.teststep.addScreenCaptureFromPath(screenShot);
			//teststep.addScreenCaptureFromPath("path to be provided");
		}
		ExtentReport.extent.flush();
		
	       

		
	}

}

package Common;

import org.openqa.selenium.By;

public class Common_functions extends driver {
	public static void closingdriver()
	{
		driver.close();
	}
	public static void logout()
	{
		 driver.findElement(By.xpath("//b[@class='zen-selectArrow']")).click();
		 driver.findElement(By.linkText("Logout")).click();
	}
	public static void edit()
	{
		driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='edit']")).click();
	}
	public static void save()
	{
		driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='save']")).click();
	}

}

package Sfbg;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Excel;
import Common.ExtentReport;

public class TS014_COR_RBM {
	@Test(priority=13)
	
	 static void opportunity() throws Exception { 
		
		Common.salesforce.teststep = ExtentReport.extent.createTest("TS013-Order creation for COR - RBM");
		Common.driver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));


		try {
			
			
			Common.salesforce.teststep.log(Status.PASS, "COR RBM order created sucessfully");
			Common.Common_functions.logout();
			
			Thread.sleep(2000);
			Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.salesdeskusername());
			 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
			 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
		     Thread.sleep(5000);
		


	Common.driver.driver.findElement(By.linkText("Opportunities")).click(); 
	Thread.sleep(2000); 
	Common.driver.driver.findElement(By.name("new")).click(); 
	Thread.sleep(2000); 
	Common.driver.driver.findElement(By.id("opp3")).sendKeys(Common.Excel.opportunityTs013()); 
	Common.driver.driver.findElement(By.id("opp4")).sendKeys("test.janet"); 
	Select type = new Select(Common.driver.driver.findElement(By.id("opp5"))); 
	type.selectByVisibleText("Change of Responsibility"); 
	Select saleschannel = new Select(Common.driver.driver.findElement(By.id("00Nb00000039oS1"))); 
	saleschannel.selectByVisibleText("Telesales"); 
	Select FA = new Select(Common.driver.driver.findElement(By.id("00Nb0000006MHJ7"))); 
	FA.selectByVisibleText("No"); 
	Common.driver.driver.findElement(By.xpath("//*[@id=\"ep\"]/div[2]/div[3]/table/tbody/tr[1]/td[4]/div/span/span/a")).click(); 
	Select stage = new Select(Common.driver.driver.findElement(By.id("opp11"))); 
	stage.selectByVisibleText("Qualified"); 
	Select primaryproduct = new Select(Common.driver.driver.findElement(By.id("00Nb00000039p5N"))); 
	primaryproduct.selectByVisibleText("Broadband"); 
	Select pm = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxyX"))); 
	pm.selectByVisibleText("No"); 
	Common.driver.driver.findElement(By.id("opp17")).sendKeys("test"); 
	Common.driver.driver.findElement(By.id("00Nb0000003s0T7")).click(); 
	Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Save & Add Product']")).click(); 
	 
	 
	
	Thread.sleep(3000); 
	Common.driver.driver.findElement(By.id("j_id0:all:j_id41:searchbox")).sendKeys("Business Broadband"); 
	Common.driver.driver.findElement(By.id("j_id0:all:j_id41:search_button")).click(); 
	Thread.sleep(2000); 
	Common.driver.driver.findElement(By.xpath("//tbody[@id='doId']//tr[1]")).click(); 
	Thread.sleep(3000); 
	Select bpt = new Select(Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id109"))); 
	bpt.selectByVisibleText("No"); 
	Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id115")).sendKeys("1"); 
	//dates 
	WebElement date1 = Common.driver.driver.findElement(By.xpath("//tbody//tr[13]//td[1]//span[1]//span[1]//a[1]")); 
	JavascriptExecutor js =(JavascriptExecutor)Common.driver.driver; 
	js.executeScript("arguments[0].click()", date1); 
	Thread.sleep(2000); 
	WebElement date2 = Common.driver.driver.findElement(By.xpath("//tbody//tr[14]//td[1]//span[1]//span[1]//a[1]")); 
	JavascriptExecutor js1 =(JavascriptExecutor)Common.driver.driver; 
	js1.executeScript("arguments[0].click()", date2); 
	Thread.sleep(2000); 
	WebElement date3 = Common.driver.driver.findElement(By.xpath("//tbody//tr[15]//td[1]//span[1]//span[1]//a[1]")); 
	JavascriptExecutor js2 =(JavascriptExecutor)Common.driver.driver; 
	js2.executeScript("arguments[0].click()", date3); 
	Thread.sleep(2000); 
	Select billfrequency = new Select(Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id137"))); 
	billfrequency.selectByVisibleText("Monthly"); 
	Select type1= new Select(Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id100"))); 
	type1.selectByVisibleText("Change of Responsibility"); 
	Select typedetail = new Select(Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id101"))); 
	typedetail.selectByVisibleText("Change of Responsibility"); 
	Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id112")).sendKeys("test"); 
	Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id114")).sendKeys("2"); 
	Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id116")).sendKeys("30"); 
	Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id124")).click(); 
	Common.driver.driver.findElement(By.xpath("//*[@id=\"calRow3\"]/td[6]")).click(); 
	WebElement rentalvalue=Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id103")); 
	rentalvalue.clear(); 
	rentalvalue.sendKeys("10"); 
	WebElement usagevalue=Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id105")); 
	usagevalue.clear(); 
	usagevalue.sendKeys("10"); 
	Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id90:saveComeBack")).click(); 
	Common.Common_functions.logout(); 
	Thread.sleep(3000); 
	 //login to BCOE
	 Thread.sleep(2000);
	 Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.Bcoeusername());
	 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
	 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
		Common.driver.driver.findElement(By.xpath("//input[@id='phSearchInput']")).sendKeys(Excel.opportunityTs013());
		Common.driver.driver.findElement(By.id("phSearchButton")).click();
		Common.driver.driver.findElement(By.linkText(Excel.opportunityTs013())).click();



		Thread.sleep(2000);
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Orders')][1]")).click();
	
		
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//input[@name='new_cor_order']")).click();


		Select Supplier = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBC")));
		Supplier.selectByValue("COR - RBM");

		Select PirmaryProd = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBJ")));
		PirmaryProd.selectByVisibleText("Broadband");
		
		Common.driver.driver.findElement(By.id("CF00N3z000009SiB6")).sendKeys("Janet J");
		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
 
	
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
		Common.driver.driver.findElement(By.xpath("//input[@name='create_suborders']")).click();
		
		Thread.sleep(3000);

		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@id='iframeContentId']")));
		Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:form1:pb1:j_id28:inputdo']")).sendKeys("1");
		Thread.sleep(1000);

		Common.driver.driver.findElement(By.name("j_id0:form1:pb1:j_id47:bottom:j_id49")).click();
		Thread.sleep(2000);

		Alert alert = Common.driver.driver.switchTo().alert();
		alert.accept();
		Common.driver.driver.switchTo().defaultContent();
		//	driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='0663z000002ZXAL']")));
		
		Thread.sleep(2000);

		Common.driver.driver.findElement(By.xpath("//div[@class='overlayDialog ']//div[@class='middle']//div[@class='innerContent']//button[text()='Close']")).click();
		Common.driver.driver.navigate().refresh();
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();

		Common.driver.driver.findElement(By.linkText("Edit")).click();


		//address details and Billing

		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBL']")).sendKeys("Sheffield");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIA']")).sendKeys("GB");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIB']")).sendKeys("United Kingdom");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBM']")).sendKeys("EC1N 2HT");



		Common.driver.driver.findElement(By.xpath("//input[@id='00N3z000009SiB4']")).sendKeys("07998889910");
		Common.driver.driver.findElement(By.xpath("//input[@value=' Save ']")).click();
 
		Common.driver.driver.findElement(By.xpath("//div[@id='Owner_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();
		//Select owner = new Select(driver.findElement(By.id("newOwn_mlktp")));
		//owner.selectByVisibleText("Queue");

		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

		String Parent1 = Common.driver.driver.getWindowHandle();

		Set<String> Child1 = Common.driver.driver.getWindowHandles();
		Iterator<String> I1 = Child1.iterator();

		while(I1.hasNext()) {

			String Child_actual = I1.next();

			if(!Parent1.equals(Child_actual)){
				Common.driver.driver.switchTo().window(Child_actual);

				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
					Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
					Common.driver.driver.switchTo().defaultContent();

					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();

				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}
		Common.driver.driver.switchTo().window(Parent1);


		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();


		Common.driver.driver.findElement(By.xpath("/html/body/div[1]/div[3]/table/tbody/tr/td[2]/div[5]/div[1]/div/form/div[2]/table/tbody/tr[2]/th/a")).click();
		Common.driver.driver.findElement(By.xpath("//div[@id='Owner_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();


		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

		String Parent11 = Common.driver.driver.getWindowHandle();

		Set<String> Child11 = Common.driver.driver.getWindowHandles();
		Iterator<String> I11 = Child11.iterator();

		while(I11.hasNext()) {

			String Child_actual = I11.next();

			if(!Parent11.equals(Child_actual)){
				Common.driver.driver.switchTo().window(Child_actual);

				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
					Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
					Common.driver.driver.switchTo().defaultContent();

					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();

				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}
		Common.driver.driver.switchTo().window(Parent11);


		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		Common.driver.driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
		Common.driver.driver.findElement(By.xpath("//a[@href='/secur/logout.jsp']")).click();

		Thread.sleep(2000);

		Common.driver.driver.findElement(By.id("username")).sendKeys("divya.suresh@mlecare.co.uk.vmbuat");
		Common.driver.driver.findElement(By.id("password")).sendKeys("Prodapt%3");


		Common.driver.driver.findElement(By.id("Login")).click();
		Thread.sleep(2000);

		 Common.driver.driver.findElement(By.xpath("//input[@id='phSearchInput']")).sendKeys(Excel.opportunityTs013());
		 Common.driver.driver.findElement(By.id("phSearchButton")).click();
		 Common.driver.driver.findElement(By.linkText(Excel.opportunityTs013())).click();
		 Thread.sleep(5000);



		//********************************Accept Parent Order****************************
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='50']")).click();


		Common.driver.driver.findElement(By.xpath("/html/body/div[1]/div[3]/table/tbody/tr/td[2]/div[25]/div[1]/div/form/div[2]/table/tbody/tr[3]/th/a")).click();

		//***********Flowtemplate

		Common.driver.driver.findElement(By.xpath("/html/body/div[1]/div[3]/table/tbody/tr/td[2]/div[4]/div[1]/table/tbody/tr/td[2]/input[8]")).click();

		//
		
		Thread.sleep(420000); //7 mins for first case
		
		Common.driver.driver.navigate().refresh();

		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
		Thread.sleep(2000);
		
	
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Create Billing Account')]//preceding-sibling::th//a")));

		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Create Billing Account')]//preceding-sibling::th//a")).click();


		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();

		Common.driver.driver.findElement(By.xpath("//div[@id='cas1_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();


		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

		String parent2 = Common.driver.driver.getWindowHandle();

		Set<String> Child2 = Common.driver.driver.getWindowHandles();
		Iterator<String> I2 = Child2.iterator();

		while(I2.hasNext()) {

			String Child_actual = I2.next();

			if(!parent2.equals(Child_actual)){
				Common.driver.driver.switchTo().window(Child_actual);

				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
					Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
					Common.driver.driver.switchTo().defaultContent();

					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();

				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}
		Common.driver.driver.switchTo().window(parent2);


		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();


		//*****************************ADDITIONAL INFORMATION**********************

		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@name='0663z000002ZXAP']")));
		Common.driver.driver.findElement(By.xpath("//td[@class='pbButton ']//input[@value='Edit']")).click();

		Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33']")).sendKeys("Test account");

		Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:gc1:j_id1:j_id28:j_id29:1:j_id33']")).sendKeys("B908");

		Select BillingSystem = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id36:0:j_id40")));

		BillingSystem.selectByVisibleText("Yorkshire (ICOMS) - 14");


		Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:gc1:j_id1:j_id56:j_id58']")).click();
		Common.driver.driver.switchTo().defaultContent();



		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();

		Select CaseStatus = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus.selectByVisibleText("Completed");

		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();

		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();

		Thread.sleep(10000); //6 mins for first case
		
		Common.driver.driver.navigate().refresh();

		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
		Thread.sleep(2000);
		
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Check Order')]//preceding-sibling::th//a")));

		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Check Order')]//preceding-sibling::th//a")).click();

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();


		Common.driver.driver.findElement(By.xpath("//div[@id='cas1_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();


		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

		String Parent3 = Common.driver.driver.getWindowHandle();

		Set<String> Child3 = Common.driver.driver.getWindowHandles();
		Iterator<String> I3 = Child3.iterator();

		while(I3.hasNext()) {

			String Child_actual = I3.next();

			if(!Parent3.equals(Child_actual)){
				Common.driver.driver.switchTo().window(Child_actual);

				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
					Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
					Common.driver.driver.switchTo().defaultContent();

					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();

				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}
		Common.driver.driver.switchTo().window(Parent3);


		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();


		//*****************************ADDITIONAL INFORMATION**********************

		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@name='0663z000002ZXAP']")));
		Common.driver.driver.findElement(By.xpath("//td[@class='pbButton ']//input[@value='Edit']")).click();
		
		WebElement ActualInstallDate = Common.driver.driver.findElement(By.xpath("/html/body/form/div[1]/div/div/div/div[2]/div/div/table/tbody/tr/td[2]/table/tbody/tr[2]/td[2]/span/input"));
		ActualInstallDate.click();
		Common.driver.driver.findElement(By.xpath("//a[@class='calToday']")).click();


		Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:gc1:j_id1:j_id56:j_id58']")).click();
		Common.driver.driver.switchTo().defaultContent();



		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();

		Select CaseStatus1 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus1.selectByVisibleText("Completed");

		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();

		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();
		

	
      Thread.sleep(10000); //5 mins for first case
		
      Common.driver.driver.navigate().refresh();

      Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
		
	
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Billing Trigger')]//preceding-sibling::th//a")));
       Thread.sleep(2000);
       Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Billing Trigger')]//preceding-sibling::th//a")).click();


       Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();

       Common.driver.driver.findElement(By.xpath("//div[@id='cas1_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();


       Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

		String Parent4 = Common.driver.driver.getWindowHandle();

		Set<String> Child4 = Common.driver.driver.getWindowHandles();
		Iterator<String> I4 = Child4.iterator();

		while(I4.hasNext()) {

			String Child_actual = I4.next();

			if(!Parent4.equals(Child_actual)){
				Common.driver.driver.switchTo().window(Child_actual);

				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
					Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
					Common.driver.driver.switchTo().defaultContent();

					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();

				}catch(Exception e){
					e.printStackTrace();
				}
			}

		}
		Common.driver.driver.switchTo().window(Parent4);


		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();


		//*****************************ADDITIONAL INFORMATION NOT REQUIRED**********************

		



		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();

		Select CaseStatus2 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus2.selectByVisibleText("Completed");

		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();

		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();
		 }
	   	catch(Throwable t) {
	   		Common.salesforce.teststep.log(Status.FAIL, "failed to create COR_RBM ORDER");
	   		Date today = new Date();
	   		SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
	   		String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
	   		File dir = new File(path1);
	   		if(!(dir.exists())){
	   			dir.mkdir();
	   			
	   		}
	   		SimpleDateFormat time = new SimpleDateFormat("hh-mm");
	   		String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Login_failed_"+time.format(today)+".png";

	   	    // Call Webdriver to click the screenshot.
	   	    File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

	   	    // Save the screenshot.
	   	    FileUtils.copyFile(scrFile, new File(screenShot));
	   		
	   			
	   		
	   		
	   		
	   		Common.salesforce.teststep.addScreenCaptureFromPath(screenShot);
	   		//teststep.addScreenCaptureFromPath("path to be provided");
	   	}
	   	ExtentReport.extent.flush();

}

}

package Sfbg;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Excel;
import Common.ExtentReport;

public class TS009_OrderCancellation {
	@Test(priority=8)
static void ordercancellation() throws Exception {
		Common.salesforce.teststep = ExtentReport.extent.createTest("TS009-Order cancellation journey");
		Common.driver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));


		
		try {
			
			
			Common.salesforce.teststep.log(Status.PASS, "order cancelled");
		
		//->****************************************************************************************
		Common.Common_functions.logout();
		Thread.sleep(3000);
		Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.Bcoeusername());
		 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
		 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
	     Thread.sleep(5000);
	     
		Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs003());
		Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
		Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
		
		
		Thread.sleep(2000);
	

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Orders')][1]")).click();
		Common.driver.driver.findElement(By.xpath("//input[@value='New Order']")).click();
		
		Thread.sleep(2000);
		
		Select Supplier = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBC")));
		Supplier.selectByVisibleText("Overlay (SF delivered)");
		
		Select Type = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBP")));
		Type.selectByVisibleText("New");
		
		Select PrimaryProd = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBJ")));
		PrimaryProd.selectByVisibleText("8X8 Back Office");
		
		Select ProjectMangedOrder = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwj")));
		ProjectMangedOrder.selectByVisibleText("No");
		
		//add billing details
		Common.driver.driver.findElement(By.name("00N3z000009SiB3")).sendKeys("11001");
		
		Select ContractTerm = new Select(Common.driver.driver.findElement(By.id("00N3z00000BpoHu")));
		ContractTerm.selectByVisibleText("3 months");
		
		Select BillingFrequency = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwU")));
		BillingFrequency.selectByVisibleText("Monthly");
		
		Select UnifiedBillingrequired = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxx5")));
		UnifiedBillingrequired.selectByVisibleText("No");
		
		
		Select BillingSystem = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwV")));
		BillingSystem.selectByVisibleText("ICOMS");
		Common.driver.driver.findElement(By.id("CF00N3z000009SiB6")).sendKeys("Janet J");
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[1]")).click();
		Thread.sleep(2000);
	Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
	Common.driver.driver.findElement(By.xpath("//input[@name='create_suborders']")).click();
	Thread.sleep(2000);
	
	Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@id='iframeContentId']")));
	Thread.sleep(1000);
	Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:form1:pb1:j_id28:inputdo']")).sendKeys("3");
	Thread.sleep(1000);
	
	Common.driver.driver.findElement(By.name("j_id0:form1:pb1:j_id47:bottom:j_id49")).click();
	
	
	Alert alert = Common.driver.driver.switchTo().alert();
	alert.accept();
	Common.driver.driver.switchTo().defaultContent();
//	driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='0663z000002ZXAL']")));
	
	Common.driver.driver.findElement(By.xpath("//div[@class='overlayDialog ']//div[@class='middle']//div[@class='innerContent']//button[text()='Close']")).click();
	Common.driver.driver.navigate().refresh();
	
	Common.driver.driver.findElement(By.xpath("//*[@class='pbBody']/table/tbody/tr[2]/th/a")).click();
	Common.driver.driver.findElement(By.xpath("//*[@id='topButtonRow']/input[3]")).click();
	
 //address details and Billing
	
	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBL']")).sendKeys("Sheffield");
	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIA']")).sendKeys("GB");
	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIB']")).sendKeys("United Kingdom");
	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBM']")).sendKeys("EC1N 2HT");
	
	Select ContractTerm1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000BpoHu")));
	ContractTerm1.selectByVisibleText("3 months");
	
	Select BillingFrequency1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwU")));
	BillingFrequency1.selectByVisibleText("Monthly");
	
	Select UnifiedBillingrequired1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxx5")));
	UnifiedBillingrequired1.selectByVisibleText("No");
	
	
	Select BillingSystem1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwV")));
	BillingSystem1.selectByVisibleText("ICOMS");
	
	Common.driver.driver.findElement(By.name("00N3z00000BpoHz")).sendKeys("100.00");
	Common.driver.driver.findElement(By.name("00N3z00000BpoI8")).sendKeys("100.00");
	
	Common.driver.driver.findElement(By.xpath("//input[@value=' Save ']")).click();
	
	Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();
	
	
	//******************************next suborder********************
	Common.driver.driver.findElement(By.xpath("//*[@class='pbBody']/table/tbody/tr[3]/th/a")).click();
	Common.driver.driver.findElement(By.xpath("//*[@id='topButtonRow']/input[3]")).click();
	
	 //address details and Billing
		
	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBL']")).sendKeys("Sheffield");
	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIA']")).sendKeys("GB");
	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIB']")).sendKeys("United Kingdom");
	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBM']")).sendKeys("EC1N 2HT");
		
		Select ContractTerm2 = new Select(Common.driver.driver.findElement(By.id("00N3z00000BpoHu")));
		ContractTerm2.selectByVisibleText("3 months");
		
		Select BillingFrequency2 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwU")));
		BillingFrequency2.selectByVisibleText("Monthly");
		
		Select UnifiedBillingrequired2 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxx5")));
		UnifiedBillingrequired2.selectByVisibleText("No");
		
		
		Select BillingSystem2 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwV")));
		BillingSystem2.selectByVisibleText("ICOMS");
		
		Common.driver.driver.findElement(By.name("00N3z00000BpoHz")).sendKeys("100.00");
		Common.driver.driver.findElement(By.name("00N3z00000BpoI8")).sendKeys("100.00");
		
		Common.driver.driver.findElement(By.xpath("//input[@value=' Save ']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();
		
		
		//*******************************next Suborder*******************************************
		
		Common.driver.driver.findElement(By.xpath("//*[@class='pbBody']/table/tbody/tr[4]/th/a")).click();
		Common.driver.driver.findElement(By.xpath("//*[@id='topButtonRow']/input[3]")).click();
		
		 //address details and Billing
			
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBL']")).sendKeys("Sheffield");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIA']")).sendKeys("GB");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIB']")).sendKeys("United Kingdom");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBM']")).sendKeys("EC1N 2HT");
			
			Select ContractTerm3 = new Select(Common.driver.driver.findElement(By.id("00N3z00000BpoHu")));
			ContractTerm3.selectByVisibleText("3 months");
			
			Select BillingFrequency3 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwU")));
			BillingFrequency3.selectByVisibleText("Monthly");
			
			Select UnifiedBillingrequired3 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxx5")));
			UnifiedBillingrequired3.selectByVisibleText("No");
			
			
			Select BillingSystem3 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwV")));
			BillingSystem3.selectByVisibleText("ICOMS");
			
			Common.driver.driver.findElement(By.name("00N3z00000BpoHz")).sendKeys("100.00");
			Common.driver.driver.findElement(By.name("00N3z00000BpoI8")).sendKeys("100.00");
			
			Common.driver.driver.findElement(By.xpath("//input[@value=' Save ']")).click(); 
			
			Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();
	

	   
		
		
	
	Common.driver.driver.findElement(By.xpath("/html/body/div[1]/div[3]/table/tbody/tr/td[2]/div[4]/div[1]/table/tbody/tr/td[2]/input[6]")).click();
	
	//Do you want to Cancel the SubOrder
	Thread.sleep(2000);
	Alert alert1 = Common.driver.driver.switchTo().alert();
	alert1.accept();
	
	Thread.sleep(5000);
	
	//Reason for PIC 
	
	Alert alert2 = Common.driver.driver.switchTo().alert();
	alert2.accept();
	
	Common.driver.driver.findElement(By.xpath("//*[@id='topButtonRow']/input[3]")).click();
	
	Select ReasonforPIC = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwv")));
	ReasonforPIC.selectByVisibleText("Customer - Customer within contract with other provider");
	
	Common.driver.driver.findElement(By.xpath("//*[@id='topButtonRow']/input[1]")).click();
	
	Common.driver.driver.findElement(By.xpath("//*[@id='topButtonRow']/input[6]")).click();
	
	//Do you want to Cancel the SubOrder
	
Thread.sleep(1000);
	Alert alert3 = Common.driver.driver.switchTo().alert();
	alert3.accept();
	
	Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
	}
	catch(Throwable t) {
		Common.salesforce.teststep.log(Status.FAIL, "failed to cancel the order");
		Date today = new Date();
		SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
		String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
		File dir = new File(path1);
		if(!(dir.exists())){
			dir.mkdir();
			
		}
		SimpleDateFormat time = new SimpleDateFormat("hh-mm");
		String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Login_failed_"+time.format(today)+".png";

	    // Call Webdriver to click the screenshot.
	    File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

	    // Save the screenshot.
	    FileUtils.copyFile(scrFile, new File(screenShot));
		
			
		
		
		
		Common.salesforce.teststep.addScreenCaptureFromPath(screenShot);
		//teststep.addScreenCaptureFromPath("path to be provided");
	}
	ExtentReport.extent.flush();
	
	
return;
}

}

package Sfbg;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Excel;
import Common.ExtentReport;


public class TS011_PartnerMailingValidation {
	
	@Test(priority=10)
	
	static void partnermailing() throws InterruptedException, IOException
	{
    	Common.salesforce.teststep = ExtentReport.extent.createTest("TS011-Partner mailing validation");
    	try {
    		Common.salesforce.teststep.log(Status.PASS, "Partner mailing validation completed sucessully");
    		
    		Common.Common_functions.logout();
    		Common.driver.driver.get("https://uat.virginmediabusiness.co.uk/wholesale/get-in-touch/partner-newsletter-mailing-list/");
    		Thread.sleep(2000);
    		
    		
    		/*String fname = "TEST";
    		String lname = "LS";
    		String Email = "vinay.S@prodapt.com";
    		String Organisation = "London pk industry";
    		String Phone = "07324577868";
    		String postcode = "EC2A 1BB";
    		String Street = " red street";
    		String city ="Newyork CITY";
    		String State = "United Kingdom";*/
    		
    		
    		
    		JavascriptExecutor js = (JavascriptExecutor)Common.driver.driver;
    		js.executeScript("window.scrollBy(0,350)", "");
    		
    		
    		//filling mandatory fields
    		Common.driver.driver.findElement(By.name("FirstName")).sendKeys(Common.Excel.fname());
    		Common.driver.driver.findElement(By.name("LastName")).sendKeys(Common.Excel.lname());
    		Common.driver.driver.findElement(By.xpath("//input[@name='Email']")).sendKeys(Common.Excel.Email());
    		Common.driver.driver.findElement(By.xpath("//input[@name='Company']")).sendKeys(Common.Excel.Organisation());
    		Common.driver.driver.findElement(By.xpath("//input[@name='Phone']")).sendKeys(Common.Excel.Phone());
    		Common.driver.driver.findElement(By.xpath("//input[@name='PostalCode']")).sendKeys(Common.Excel.postcode());
    		Common.driver.driver.findElement(By.xpath("//input[@name='Street']")).sendKeys(Common.Excel.Street1());
    		Common.driver.driver.findElement(By.xpath("//input[@name='city']")).sendKeys(Common.Excel.city());
    		Common.driver.driver.findElement(By.xpath("//input[@name='State']")).sendKeys(Common.Excel.State());
    		
    		Common.driver.driver.findElement(By.xpath("//span[@class='lgi-checkbox-imagePlaceholder']")).click();
    		
    		Thread.sleep(2000);
    		js.executeScript("window.scrollBy(0,150)", "");
    		
    		//submitting the form
    		WebElement submit = Common.driver.driver.findElement(By.xpath("//button[@type='submit']"));
    		
    		
    		
    		JavascriptExecutor js1 = (JavascriptExecutor)Common.driver.driver;
    		js1.executeScript("arguments[0].click()", submit);
    		
    		
    		Thread.sleep(20000);
    		
    		 Common.driver.driver.get("https://vmb--vmbuat.my.salesforce.com/");
    		//login to salesforce
			 Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.salesdeskusername());
			 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
			 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
		     Thread.sleep(2000);
    	
		Common.driver.driver.findElement(By.linkText("Leads")).click();
		Select view = new Select(Common.driver.driver.findElement(By.name("fcf")));
		view.selectByVisibleText("Partner Mailing Leads");
		Common.driver.driver.findElement(By.xpath("//input[@title='Go!']")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.linkText(Common.Excel.leadname())).click();
		
		File src = ((TakesScreenshot)Common.driver.driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("user.dir"+"\\Screenshots\\proof.png"));
		
		Thread.sleep(3000);
		
		JavascriptExecutor js11 = (JavascriptExecutor)Common.driver.driver;
		js11.executeScript("window.scrollBy(0,350)", "");
		
		File src1 = ((TakesScreenshot)Common.driver.driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src1, new File("user.dir"+"\\stagescreenshot\\proof1.png"));
		
		Thread.sleep(3000);
    	
		Common.driver.driver.findElement(By.linkText("[Change]")).click();
		Common.driver.driver.findElement(By.xpath("//img[@alt='Owner Lookup (New Window)']")).click();
		Set<String> handlewindow = Common.driver.driver.getWindowHandles();
		Iterator<String> itr = handlewindow.iterator();
		String parent = itr.next();
		String child = itr.next();
		Common.driver.driver.switchTo().window(child);
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.name("searchFrame")));
		Common.driver.driver.findElement(By.id("lksrch")).sendKeys("radhika");
		Common.driver.driver.findElement(By.name("go")).click();
		Common.driver.driver.switchTo().defaultContent();
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.name("resultsFrame")));
		Common.driver.driver.findElement(By.linkText("Radhika Jayachandran Salesdesk")).click();
		Common.driver.driver.switchTo().window(parent);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		
		//changing stage
		
		Actions a = new Actions(Common.driver.driver);
		a.moveToElement(Common.driver.driver.findElement(By.id("lea13_ileinner"))).doubleClick().build().perform();
		Thread.sleep(2000);
		
		Select status = new Select(Common.driver.driver.findElement(By.id("lea13")));
		status.selectByValue("Qualified");
		
		Common.driver.driver.findElement(By.xpath("//input[@value='OK']")).click();
		
		a.moveToElement(Common.driver.driver.findElement(By.id("00N8E00000Au1ql_ileinner"))).doubleClick().build().perform();
		Select consent = new Select(Common.driver.driver.findElement(By.id("00N8E00000Au1ql")));
		consent.selectByValue("No");
		
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[1]")).click();
    	
		Thread.sleep(5000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[5]")).click();
		Common.driver.driver.findElement(By.name("j_id0:all:j_id42:j_id49:j_id60:j_id64")).click();
		Common.driver.driver.findElement(By.name("j_id0:all:j_id42:j_id43:conv")).click();
		
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Contacts')]")).click();
		Common.driver.driver.findElement(By.xpath("//div[@class='pbBody']//th[@scope='row']//a")).click();
		
		Thread.sleep(1000);
		
		JavascriptExecutor js111 = (JavascriptExecutor)Common.driver.driver;
		js111.executeScript("window.scrollBy(0,0)", "");
		
		Thread.sleep(2000);		
		File src2 = ((TakesScreenshot)Common.driver.driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src2, new File("user.dir"+"\\contactscreenshot\\proof1.png"));
		
    	}catch(Throwable t) {
			Common.salesforce.teststep.log(Status.FAIL, "Failed to move to contact page");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\contact_"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
				
			
			
			
			Common.salesforce.teststep.addScreenCaptureFromPath(screenShot);
			//teststep.addScreenCaptureFromPath("path to be provided");
		}
		ExtentReport.extent.flush();
	       
		
	}

}

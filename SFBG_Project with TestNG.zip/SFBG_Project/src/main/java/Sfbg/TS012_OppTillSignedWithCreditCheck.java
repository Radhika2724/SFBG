package Sfbg;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Excel;
import Common.ExtentReport;


public class TS012_OppTillSignedWithCreditCheck {
	
	@Test(priority=11)
	
	static void creatingopp() throws IOException
	{
Common.salesforce.teststep = ExtentReport.extent.createTest("TS012-Opportunity Creation with credit check");
		
		try {
			
			
			Common.salesforce.teststep.log(Status.PASS, "Opportunity created sucessfully with credit check");
			Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.salesdeskusername());
			 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
			 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
		     Thread.sleep(5000);
Common.driver.driver.findElement(By.xpath("//a[@title='Opportunities Tab']")).click();
			
			Common.driver.driver.findElement(By.name("new")).click();
			 
			Common.driver.driver.findElement(By.id("opp3")).sendKeys(Excel.opportunityTs012());
			 
			Common.driver.driver.findElement(By.id("opp4")).sendKeys("test.janet");
			 
			 WebElement type = Common.driver.driver.findElement(By.id("opp5"));
			 Select a = new Select(type);
			 a.selectByValue("New");
			 
			 WebElement typedetails = Common.driver.driver.findElement(By.id("00Nb00000039oS4"));
			 Select td = new Select(typedetails);
			 td.selectByValue("New Business");
			 
			 WebElement sales= Common.driver.driver.findElement(By.id("00Nb00000039oS1"));
			 Select b = new Select(sales);
			 b.selectByValue("Telesales");
			 
			 WebElement FA = Common.driver.driver.findElement(By.id("00Nb0000006MHJ7"));
			 Select c = new Select (FA);
			 c.selectByValue("No");
			 
			WebElement productintrest = Common.driver.driver.findElement(By.id("00Nb00000039p5N"));
			Select d = new Select(productintrest);
			d.selectByValue("Broadband");
			
			Common.driver.driver.findElement(By.xpath("//*//table[@id='bodyTable']//tbody//tr//td[2]//form//table[@class='detailList']//tbody//tr//td[4]//div[1]//span//span[@class='dateFormat']//a")).click();
			WebElement stage = Common.driver.driver.findElement(By.id("opp11"));
			Select e = new Select(stage);
			e.selectByValue("Qualified");
			
			WebElement pm = Common.driver.driver.findElement(By.id("00N3z00000CWxyX"));
			Select f = new Select(pm);
			f.selectByValue("No");
			
			Common.driver.driver.findElement(By.id("opp17")).sendKeys("test");
			
			Common.driver.driver.findElement(By.xpath("//input[@value='Save & Add Product']")).click();
			
			


			//adding the products
			Common.driver.driver.findElement(By.id("j_id0:all:j_id41:searchbox")).sendKeys(Excel.product());
			Common.driver.driver.findElement(By.name("j_id0:all:j_id41:search_button")).click();
			Thread.sleep(4000);
			
			Common.driver.driver.findElement(By.xpath("//table[@id='prodTable']//tr[1]//td[1]")).click();
			Thread.sleep(2000);
			  //add TCV values ->Install->Total rental ->Usage

		  	Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:all:selectedproducts:j_id94:0:j_id96:installValue']")).clear();
		  	Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:all:selectedproducts:j_id94:0:j_id96:installValue']")).sendKeys("10.00");

		  	Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:all:selectedproducts:j_id94:0:j_id96:totRentalValue']")).clear();
		  	Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:all:selectedproducts:j_id94:0:j_id96:totRentalValue']")).sendKeys("10.00");

		  	Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:all:selectedproducts:j_id94:0:j_id96:j_id104']")).clear();
		  	Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:all:selectedproducts:j_id94:0:j_id96:j_id104']")).sendKeys("10.00");
			
			
			
			 WebElement bpt = Common.driver.driver.findElement(By.name("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id109"));
		      Select bp = new Select (bpt);
		      bp.selectByValue("No");
			
		      Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id115")).sendKeys("1");
			
			//dates
			WebElement date =Common.driver.driver.findElement(By.xpath("//tbody/tr[13]/td[1]/div[1]/span[1]/span[1]/a[1]"));
			  JavascriptExecutor js = (JavascriptExecutor)Common.driver.driver;
			   	js.executeScript("arguments[0].click()", date);
			Thread.sleep(2000);
		   WebElement ele =Common.driver.driver.findElement(By.xpath("//tbody/tr[14]/td[1]/span[1]/span[1]/a[1]"));
		      
		  	js.executeScript("arguments[0].click()", ele);
		      
		      Thread.sleep(2000);
		     
		    WebElement ele1=  Common.driver.driver.findElement(By.xpath("//tbody/tr[15]/td[1]/span[1]/span[1]/a[1]"));
		    
			js.executeScript("arguments[0].click()", ele1);
			Thread.sleep(2000);
			WebElement billing = Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id137"));
			Select bill = new Select (billing);
			bill.selectByValue("Monthly");
			   Thread.sleep(1000);                                          //j_id0:all:selectedproducts:j_id94:0:j_id96:j_id100
			 WebElement type1 = Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id100"));
			 Select ab = new Select(type1);
			 ab.selectByValue("New");
			 Thread.sleep(1000);
			 
			 WebElement typedetails1 = Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id101"));
			 Select td1 = new Select(typedetails1);
			 td1.selectByValue("New Business");
			 
			 Thread.sleep(3000);
			 Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:all:selectedproducts:j_id90:saveComeBack']")).click(); 
			 Thread.sleep(3000);
		Common.Common_functions.logout();
	
		
		 //login to BCOE
		 Thread.sleep(2000);
		 Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.Bcoeusername());
		 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
		 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
		 
				
				Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs012());
				Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
				Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
		    	
				Common.driver.driver.findElement(By.xpath("//input[@name='edit']")).click();
				Common.driver.driver.findElement(By.xpath("//input[@name='00Nb000000ADKJ5']")).click();
		    	
				Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		    	Common.driver.driver.navigate().refresh();
		
				Common.driver.driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
				Common.driver.driver.findElement(By.xpath("//a[@href='/secur/logout.jsp']")).click();
		    	
				Thread.sleep(2000);
				Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.salesdeskusername());
				 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
				 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
			     Thread.sleep(5000);
			     Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs012());
					Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
					Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
			    	
				
				Common.driver.driver.findElement(By.xpath("//input[@title='Submit for Approval']")).click();
	Alert alert = Common.driver.driver.switchTo().alert();
		    	alert.accept();
		    	
				
		    	Thread.sleep(3000);
				
				Common.driver.driver.findElement(By.xpath("//input[@name='edit']")).click();
		    	
		    	Select awaitingStage = new Select(Common.driver.driver.findElement(By.id("opp11")));
		    	awaitingStage.selectByVisibleText("Awaiting Contract");
		    	
		    	Common.driver.driver.findElement(By.xpath("//input[@name='00Nb0000003s0T7']")).click();
		    	Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		    	
				Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@id='066b0000001NDxa']")));
		    	Actions actOne = new Actions(Common.driver.driver);
		           
		        WebElement element = Common.driver.driver.findElement(By.xpath(".//*[@id='j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_1_j_id11_ileinner']"));
		        actOne.doubleClick(element).perform();
		       
		        Common.driver.driver.findElement(By.xpath(".//*[@id='j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_1_j_id11']")).sendKeys("Test Document");
		        
		        
		        Actions actTwo = new Actions(Common.driver.driver);
		       
		        WebElement elementTwo = Common.driver.driver.findElement(By.xpath(".//*[@id='j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11_ileinner']"));
		        actTwo.doubleClick(elementTwo).perform();
		        Common.driver.driver.findElement(By.xpath(".//*[@id='j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11']")).sendKeys("https://test.com");
		        
		//save document section
		        Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:j_id1:j_id3:j_id4:j_id5']")).click();
		        Common.driver.driver.switchTo().defaultContent();
				
				Common.driver.driver.findElement(By.xpath("//input[@name='credit_check']")).click();
				
				Common.driver.driver.findElement(By.xpath("//input[@id='p:i:i:f:pb:d:Company_Registration_Number.input']")).sendKeys("68889");
				Common.driver.driver.findElement(By.xpath("//input[@name='p:i:i:f:pb:pbb:bottom:next']")).click();
		        
				Common.driver.driver.findElement(By.xpath("//input[@name='p:i:i:f:pb:pbb:bottom:next']")).click();
				Common.driver.driver.findElement(By.xpath("//input[@name='p:i:i:f:pb:pbb:bottom:finish']")).click();
		        
				Common.driver.driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
				Common.driver.driver.findElement(By.xpath("//a[@href='/secur/logout.jsp']")).click();
		        
				Thread.sleep(2000);
				Common.driver.driver.findElement(By.id("username")).sendKeys("divya.suresh@mlecare.co.uk.vmbuat");
				Common.driver.driver.findElement(By.id("password")).sendKeys("Prodapt%3");
				Common.driver.driver.findElement(By.id("Login")).click();
				//Common.driver.driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
				Thread.sleep(2000);
				Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs012());
				Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
				Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
		    	
		    	
		
				Common.driver.driver.findElement(By.linkText("Credit and Collections Check Request")).click();
				
				Common.driver.driver.findElement(By.xpath("//a[text()[normalize-space(.)= '[Change]']]")).click();
				Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();
		        String parent = Common.driver.driver.getWindowHandle();
				
				Set<String> child = Common.driver.driver.getWindowHandles();
				Iterator<String> i = child.iterator();
				
				while(i.hasNext()) {
					
					String child_actual = i.next();
					
					if(!parent.equals(child_actual)){
						Common.driver.driver.switchTo().window(child_actual);
						Common.driver.driver.manage().window().fullscreen();
						try {
							Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
							Common.driver.driver.findElement(By.xpath("//div[@class='pbBody']//table//a[contains(text(),'divya Suresh MLE Care')]")).click();
						}catch(Exception e1){
							e1.printStackTrace();
						}
					}
					
				}
				
				Common.driver.driver.switchTo().window(parent);
				Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
			
				Common.driver.driver.findElement(By.xpath("//input[@name='edit']")).click();
				
				Select CaseResult = new Select(Common.driver.driver.findElement(By.id("00Nb000000ALD5g")));
				CaseResult.selectByVisibleText("Accept");
				
				Common.driver.driver.findElement(By.xpath("//input[@name='00Nb000000ALD5n']")).sendKeys("4000");
				Common.driver.driver.findElement(By.xpath("//input[@name='save_close']")).click();
				
				Select Status = new Select(Common.driver.driver.findElement(By.id("cas7")));
				Status.selectByVisibleText("Completed");
				
				Select ClosedReason = new Select(Common.driver.driver.findElement(By.id("00ND00000035zsG")));
				ClosedReason.selectByVisibleText("Completed");
				
				
				Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
			
				Common.driver.driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
				Common.driver.driver.findElement(By.xpath("//a[@href='/secur/logout.jsp']")).click();
		    	
				Common.driver.driver.findElement(By.id("username")).sendKeys("divya.suresh@salesagent.co.uk.vmbuat");
				Common.driver.driver.findElement(By.id("password")).sendKeys("Prodapt%3");
				Common.driver.driver.findElement(By.id("Login")).click();
				Thread.sleep(2000);
				//Common.driver.driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		    	//driver.findElement(By.xpath("//span[@class='uiImage']")).click();
		    	//driver.findElement(By.xpath("//a[@class='profile-link-label switch-to-aloha uiOutputURL']")).click();

		//--------------------------------------------------------------------------------------------------------->* 	
		    	
				Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys("OP000993510");
				Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
				Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
				
				Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs012());
				Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
				Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
		    	
		    	
		    	
		    	
				Common.driver.driver.findElement(By.xpath("//input[@name='edit']")).click();
		    	
		    	Select SubmitStage = new Select(Common.driver.driver.findElement(By.id("opp11")));
		    	SubmitStage.selectByVisibleText("Submit Contract");
		    	Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		    	//Common.driver.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		    	Thread.sleep(2000);
				
				Common.driver.driver.findElement(By.xpath("//input[@name='new00Nb0000009Fbzj']")).click();
		    	
		    	Select SalesType = new Select(Common.driver.driver.findElement(By.id("p3")));
		    	SalesType.selectByVisibleText("Business Enablement and Managed Service Desk");
		    	
		    	Common.driver.driver.findElement(By.xpath("//input[@value='Continue']")).click();
		    	
		    	
		    	Select EngageGroup = new Select(Common.driver.driver.findElement(By.id("00Nb0000009Fbzp")));
		    	EngageGroup.selectByVisibleText("Business Enablement Enterprise");
		    	
		    	Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@title='Rich Text Editor, 00Nb0000009FbzbEAC']")));
		    	Common.driver.driver.findElement(By.xpath("//*[@class='cke_editable cke_editable_themed cke_contents_ltr cke_show_borders']")).sendKeys("test Sales Engagement");
		    	
		    	Common.driver.driver.switchTo().defaultContent();
		    	Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		    	
		    	Common.driver.driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
		    	Common.driver.driver.findElement(By.xpath("//a[@href='/secur/logout.jsp']")).click();
		    	
			
				Common.driver.driver.findElement(By.id("username")).sendKeys("divya.suresh@bcoe.co.uk.vmbuat");
				Common.driver.driver.findElement(By.id("password")).sendKeys("Prodapt%3");
				Common.driver.driver.findElement(By.id("Login")).click();
				//Common.driver.driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
				Thread.sleep(2000);
		//------------------------------------------------------------------------------------------------------------->           	
				Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs012());
				Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
				Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
		    	
		    	
		//check order audit complete :
				Common.driver.driver.findElement(By.xpath("//input[@name='edit']")).click();
				Common.driver.driver.findElement(By.xpath("//input[@name='00Nb0000009scG8']")).click();
				Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		    	
		    	//close SE task
				Common.driver.driver.findElement(By.xpath("//span[contains(text(), 'Sales Engagements')]")).click();
		    	
				Common.driver.driver.findElement(By.xpath("//div[@class='listRelatedObject Custom57Block']//table[@class='list']//th[@scope='row']")).click();
				Common.driver.driver.findElement(By.xpath("//input[@name='edit']")).click();
		    	Select RequestStatus = new Select(Common.driver.driver.findElement(By.id("00Nb0000009Fbzv")));
		    	RequestStatus.selectByVisibleText("Completed - Resolved");
		    	
		    	Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
				
		    	
				Common.driver.driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
				Common.driver.driver.findElement(By.xpath("//a[@href='/secur/logout.jsp']")).click();
		    	
				Common.driver.driver.findElement(By.id("username")).sendKeys("divya.suresh@salesagent.co.uk.vmbuat");
				Common.driver.driver.findElement(By.id("password")).sendKeys("Prodapt%3");
				Common.driver.driver.findElement(By.id("Login")).click();
		    	//Common.driver.driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
				Thread.sleep(2000);
		    	//driver.findElement(By.xpath("//span[@class='uiImage']")).click();
		    	//driver.findElement(By.xpath("//a[@class='profile-link-label switch-to-aloha uiOutputURL']")).click();
		//--------------------------------------------------------------------------------------------------------------------->          	
				Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs012());
				Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
				Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
		    	
		    	
		    	Common.driver.driver.findElement(By.xpath("//input[@name='edit']")).click();
		    	Select SignedStage = new Select(Common.driver.driver.findElement(By.id("opp11")));
		    	SignedStage.selectByVisibleText("Signed Contract");
		    	
		    	Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
				
			
				Common.driver.driver.findElement(By.xpath("//input[@name='submit']")).click();
		    	
		    	Alert alertTwo = Common.driver.driver.switchTo().alert();
		    	alertTwo.accept();
		    	
		    	Common.driver.driver.navigate().refresh();
		    	
			
		}catch(Throwable t) {
			Common.salesforce.teststep.log(Status.FAIL,"Failed to create the opportunity with creditcheck");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Error in quoted stage"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
		}
		ExtentReport.extent.flush();
		
			     

			}
			

}

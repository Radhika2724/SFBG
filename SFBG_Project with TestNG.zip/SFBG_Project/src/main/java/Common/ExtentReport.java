package Common;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {
	
	private static ExtentSparkReporter reporter;
	public static ExtentReports extent;
	
	public static void initializereportervariable() {
		Date today = new Date();
		SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
		String path1 = (System.getProperty("user.dir")+"\\Execution_Reports"+dateformat.format(today));
		File dir = new File(path1);
		if(!(dir.exists())){
			dir.mkdir();
			
		}
		SimpleDateFormat time = new SimpleDateFormat("hh-mm");
		
			
		
		reporter = new ExtentSparkReporter(System.getProperty("user.dir")+"\\Execution Reports\\"+dateformat.format(today)+"\\Extent_Report_"+time.format(today)+".html");
		reporter.config().setDocumentTitle("Test results");
		reporter.config().setReportName("Automation test");
		
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		
		extent.setSystemInfo("Environment", "UAT");
	    
		return;
			
	}

}

package Sfbg;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.ExtentReport;

public class TS024_ComplaintCaseCreation {
	
	@Test(priority=1)
	static void loginAndNavigateToCaseSelectionPage() throws InterruptedException, IOException {
		
		Common.salesforce.teststep = ExtentReport.extent.createTest("TS024-Complaint Case creation");
		Common.driver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		try {
			Thread.sleep(2000);
			
			 Common.Common_functions.logout();
			 Common.salesforce.teststep.log(Status.PASS, "Complaint case created sucessfully");

		Common.driver.driver.findElement(By.id("username")).sendKeys("divya.suresh@mlecare.co.uk.vmbuat");
		Common.driver.driver.findElement(By.id("password")).sendKeys("Prodapt%3");
		Common.driver.driver.findElement(By.id("Login")).click();
		
		Thread.sleep(2000);
		
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Common.driver.driver.findElement(By.linkText("Cases")).click();
		Common.driver.driver.findElement(By.xpath("//input[@name='new']")).click();
		
	
		
		Common.driver.driver.findElement(By.id("p3"));
		Select dropdown = new Select(Common.driver.driver.findElement(By.id("p3")));
		
		dropdown.selectByVisibleText("caseName");
		Common.driver.driver.findElement(By.xpath("//input[@value='Continue']")).click();
		

		Common.driver.driver.findElement(By.xpath("//a[@title='Account Name Lookup (New Window)']")).click();
		
		String parent = Common.driver.driver.getWindowHandle();
		
		Set<String> child = Common.driver.driver.getWindowHandles();
		Iterator<String> i = child.iterator();
		
		while(i.hasNext()) {
			
			String child_actual = i.next();
			
			if(!parent.equals(child_actual)){
				Common.driver.driver.switchTo().window(child_actual);
				Common.driver.driver.manage().window().fullscreen();
				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//div[@id='Account_body']//table//tr//a[contains(text(),'test')]")).click();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		
		Common.driver.driver.switchTo().window(parent);
		
	
			
			Select dropdown1 = new Select(Common.driver.driver.findElement(By.id("00N3z000006YuGU")));
			//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("00N3z000006YuGU"))));
			dropdown1.selectByVisibleText("Direct");
			
			Select dropdown2 = new Select(Common.driver.driver.findElement(By.id("00N3z000006hCJE")));
			dropdown2.selectByVisibleText("MDO");
			
			Select dropdown3 = new Select(Common.driver.driver.findElement(By.id("00ND0000006Va7L")));
			dropdown3.selectByVisibleText("Email");
			
			Select dropdown4 = new Select(Common.driver.driver.findElement(By.id("00ND0000006orG8")));
			dropdown4.selectByVisibleText("Mobile Complaint");
			
			Select dropdown5 = new Select(Common.driver.driver.findElement(By.id("00ND0000006orG9")));
			dropdown5.selectByVisibleText("Billing");
			
			Select dropdown6 = new Select(Common.driver.driver.findElement(By.id("00N3z000006hBqq")));
			dropdown6.selectByVisibleText("Account Manager");
			
			Select dropdown7 = new Select(Common.driver.driver.findElement(By.id("cas8")));
			dropdown7.selectByVisibleText("Medium");
			
			Select dropdown8 = new Select(Common.driver.driver.findElement(By.id("00N3z000006hBqe")));
			dropdown8.selectByVisibleText("No");
			
			Select dropdown9 = new Select(Common.driver.driver.findElement(By.id("00N3z000009UnFf")));
			dropdown9.selectByVisibleText("No");
			
			Select dropdown10 = new Select(Common.driver.driver.findElement(By.id("00N8E000006lICT")));
			dropdown10.selectByVisibleText("CISAS");
			
			Common.driver.driver.findElement(By.id("00Nb000000ADSLJ")).sendKeys("1234");
			Common.driver.driver.findElement(By.id("cas15")).sendKeys("test complaints case");
			
		
		Common.driver.driver.findElement(By.xpath("//a[@title='Contact Name Lookup (New Window)']")).click();
		
		String parent1 = Common.driver.driver.getWindowHandle();
		
		Set<String> child1 = Common.driver.driver.getWindowHandles();
		Iterator<String> i1 = child1.iterator();
		
		while(i1.hasNext()) {
			
			String child_actual = i1.next();
			
			if(!parent1.equals(child_actual)){
				Common.driver.driver.switchTo().window(child_actual);
				Common.driver.driver.manage().window().fullscreen();
				try {
					
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					Common.driver.driver.findElement(By.id("lksrch")).sendKeys("test james rao");
					Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
					Common.driver.driver.switchTo().defaultContent();
    				
    				
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();
					
					
					
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		
		
	Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
	Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		}
		catch(Throwable t) {
			Common.salesforce.teststep.log(Status.FAIL, "failed to create Complaint case");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Login_failed_"+time.format(today)+".png";

		   // Call Webdriver to click the screenshot.
		   File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

		   // Save the screenshot.
		   FileUtils.copyFile(scrFile, new File(screenShot));
			
				
			
			
			
			Common.salesforce.teststep.addScreenCaptureFromPath(screenShot);
			//teststep.addScreenCaptureFromPath("path to be provided");
		}
		ExtentReport.extent.flush();
		Common.driver.driver.quit();
	
}
	

}
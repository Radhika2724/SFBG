package Common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	static FileInputStream fis;
	static HSSFWorkbook workbook;
	static HSSFSheet sheet;
		
			// TODO Auto-generated method stub
			public static String salesdeskusername() throws Exception{
			  fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
			  workbook = new HSSFWorkbook(fis);//C:\Users\radhika.j\eclipse-workspace\SFBG_Project\src\main\java\Common\TestData.xls
			  sheet =workbook.getSheet("Sheet1");
			  String login = sheet.getRow(1).getCell(0).getStringCellValue();
			return login;
			  
			  
		}
			public static String Bcoeusername() throws Exception{
				  fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet1");
				  String bcoelogin = sheet.getRow(2).getCell(0).getStringCellValue();
				  //System.out.println(login);
				return bcoelogin;
				  
				  
			}
			public static String pwd() throws Exception
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet1");
				  String pwd = sheet.getRow(1).getCell(1).getStringCellValue();
				
				return pwd;
			}
			public static String opportunity() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet1");
				  String opp_name = sheet.getRow(1).getCell(2).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs002() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(2).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs003() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(3).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs004() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(4).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs005() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(5).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs006() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(6).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs007() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(7).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs008() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(8).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs009() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(9).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs012() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(12).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String opportunityTs013() throws Exception
			{
				fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet4");
				  String opp_name = sheet.getRow(13).getCell(0).getStringCellValue();
				
				return opp_name;
			}
			public static String product() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet1");
				  String product = sheet.getRow(1).getCell(3).getStringCellValue();
				 
				return product;
			}
			public static String Leadname() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String leadname = sheet.getRow(1).getCell(9).getStringCellValue();
				 
				return leadname;
			}
			public static String firstname() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String firstname = sheet.getRow(1).getCell(0).getStringCellValue();
				 
				return firstname;
			}
			public static String Lastname() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String Lastname = sheet.getRow(1).getCell(1).getStringCellValue();
				 
				return Lastname;
			}
			public static String email() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String email = sheet.getRow(1).getCell(2).getStringCellValue();
				 
				return email;
			}
			public static String contact() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String contact = sheet.getRow(1).getCell(3).getStringCellValue();
				 
				return contact;
			}
			public static String Street() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String Street = sheet.getRow(1).getCell(5).getStringCellValue();
				 
				return Street;
			}
			public static String City() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String City = sheet.getRow(1).getCell(6).getStringCellValue();
				 
				return City;
			}
			public static String Zipcode() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String zipcode = sheet.getRow(1).getCell(7).getStringCellValue();
				 
				return zipcode;
			}
			public static String Country() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet2");
				  String Country = sheet.getRow(1).getCell(8).getStringCellValue();
				 
				return Country;
			}
			public static String fname() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String fname = sheet.getRow(1).getCell(0).getStringCellValue();
			
				return fname;
				
			}
			public static String lname() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String lname =  sheet.getRow(1).getCell(1).getStringCellValue();;
			
				return lname;
				
			}
			public static String Email() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String email =  sheet.getRow(1).getCell(2).getStringCellValue();
			
				return email;
				
			}
			public static String Organisation() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String Organisation =  sheet.getRow(1).getCell(3).getStringCellValue();
			
				return Organisation;
				
			}
			public static String Phone() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String Phone =  sheet.getRow(1).getCell(4).getStringCellValue();
			
				return Phone;
				
			}
			public static String postcode() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String postcode =  sheet.getRow(1).getCell(5).getStringCellValue();
			
				return postcode;
				
			}
			public static String Street1() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String street =  sheet.getRow(1).getCell(6).getStringCellValue();
			
				return street;
				
			}
			public static String city() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String city =  sheet.getRow(1).getCell(7).getStringCellValue();
			
				return city;
				
			}
			public static String State() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String state =  sheet.getRow(1).getCell(8).getStringCellValue();
			
				return state;
				
			}
			public static String leadname() throws IOException
			{
				 fis = new FileInputStream("C:\\Users\\radhika.j\\eclipse-workspace\\SFBG_Project\\src\\main\\java\\Common\\TestData.xls");
				  workbook = new HSSFWorkbook(fis);
				  sheet =workbook.getSheet("Sheet3");
				String leadname =  sheet.getRow(1).getCell(9).getStringCellValue();
			
				return leadname;
				
			}
		}

		

package Sfbg;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Excel;
import Common.ExtentReport;

public class TS019_BackofficeCancellation {
	@Test(priority=0)
	public static void orders() throws Exception
	{
		Common.salesforce.teststep = ExtentReport.extent.createTest("TS019-order for 8X8 backoffice product cancellation");
		
		try {
			
			
			Common.salesforce.teststep.log(Status.PASS, "order cancelled sucessfully");
			Thread.sleep(2000);
			Common.Common_functions.logout();
			
			 Thread.sleep(2000);
			 Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.Bcoeusername());
			 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
			 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();

			Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs007());
			Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
			Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
			
			
			
		Thread.sleep(4000);
		
		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//a[19]")).click();

		Common.driver.driver.findElement(By.name("new_sub_order")).click();
		Common.driver.driver.findElement(By.name("CF00N3z000009SiB6")).sendKeys("Janet J");


		Select supplier = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBC")));
		supplier.selectByValue("VMB Direct");

		Select primaryproduct = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBJ")));
		primaryproduct.selectByValue("8X8 Back Office");//8X8 Contact Centre

		Select pm = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwj")));
		pm.selectByValue("No");

		// Billing details
		Common.driver.driver.findElement(By.id("00N3z000009SiB3")).sendKeys("05847463");
		Select freq = new Select(Common.driver.driver.findElement(By.id("00N3z00000BpoHu")));
		freq.selectByValue("3 months");

		Select bill = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwU")));
		bill.selectByValue("Monthly");

		Select unifiedbill = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxx5")));
		unifiedbill.selectByValue("No");

		Common.driver.driver.findElement(By.xpath("//*[@id=\"ep\"]/div[2]/div[5]/table/tbody/tr[5]/td[2]/span/span/a")).click();

		Select billingsys = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwV")));
		billingsys.selectByValue("ICOMS");

		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[1]")).click();


		// -----------------------------------------------------------------------------------------------------------------
		  Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//a//span[contains(text(),'Orders (Sub Order)')]")).click(); 
		  Common.driver.driver.findElement(By.name("create_suborders")).click();
		  Thread.sleep(3000);
		  Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("iframeContentId")));
		  Common.driver.driver.findElement(By.id("j_id0:form1:pb1:j_id28:inputdo")).sendKeys("1");
		  Common.driver.driver.findElement(By.id("j_id0:form1:pb1:j_id47:bottom:j_id49")).click();
		  Common.driver.driver.switchTo().alert().accept(); 
		  Common.driver.driver.switchTo().defaultContent();
		  Common.driver.driver.findElement(By.xpath("//button[@class='btn']")).click();
		  Common.driver.driver.navigate().refresh();
		  String order = Common.driver.driver.findElement(By.xpath("//div[@id='Name_ileinner']")).getText();
		  order = order.replaceAll("[A-Z]","");
		    order = order.replaceAll("-","");
		    int ordernumber = Integer.parseInt(order);
		     int suborder1 = ordernumber+1;
		     String str1 = Integer.toString(suborder1);
		      String suborder = "SO-0000"+str1;
		      System.out.println(suborder);
		 

		      Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//a//span[contains(text(),'Orders (Sub Order)')]"))
				.click();
		
		      Common.driver.driver.findElement(By.linkText(suborder)).click();
		      Thread.sleep(3000);
		      
		      Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[3]")).click();
		      Thread.sleep(1000);
		    //address details and Billing
		  	
		  	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBL']")).sendKeys("Sheffield");
		  	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIA']")).sendKeys("GB");
		  	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIB']")).sendKeys("United Kingdom");
		  	Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBM']")).sendKeys("EC1N 2HT");
		  	
		  	Select ContractTerm1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000BpoHu")));
		  	ContractTerm1.selectByVisibleText("3 months");
		  	
		  	Select BillingFrequency1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwU")));
		  	BillingFrequency1.selectByVisibleText("Monthly");
		  	
		  	Select UnifiedBillingrequired1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxx5")));
		  	UnifiedBillingrequired1.selectByVisibleText("No");
		  	
		  	
		  	Select BillingSystem1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwV")));
		  	BillingSystem1.selectByVisibleText("ICOMS");
		  	
		  	Common.driver.driver.findElement(By.name("00N3z00000BpoHz")).sendKeys("100.00");
		  	Common.driver.driver.findElement(By.name("00N3z00000BpoI8")).sendKeys("100.00");
		  	
		  	Common.driver.driver.findElement(By.xpath("//input[@value=' Save ']")).click();
		  
		  
		  
		  String suborder2 = Common.driver.driver.findElement(By.xpath("//*[@id=\"Name_ileinner\"]")).getText();
		  
		  
		  Common.driver.driver.findElement(By.xpath("//div[@id='Owner_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();
			//Select owner = new Select(driver.findElement(By.id("newOwn_mlktp")));
			//owner.selectByVisibleText("Queue");
			
			Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

			String Parent = Common.driver.driver.getWindowHandle();

			Set<String> Child = Common.driver.driver.getWindowHandles();
			Iterator<String> I = Child.iterator();

			while(I.hasNext()) {
				
				String Child_actual = I.next();
				
				if(!Parent.equals(Child_actual)){
					Common.driver.driver.switchTo().window(Child_actual);
					
					try {
						Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
						Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
						Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
						Common.driver.driver.switchTo().defaultContent();
						
						Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
						Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();
						
					}catch(Exception e){
						e.printStackTrace();
					}
				}
				
			}
			Common.driver.driver.switchTo().window(Parent);
			

			Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
			Thread.sleep(2000);

			Common.driver.driver.findElement(By.xpath("//div[@id='CF00N3z00000BpoI4_ileinner']//a")).click();
			Common.driver.driver.findElement(By.xpath("//div[@id='Owner_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();
			//Select owner1 = new Select(driver.findElement(By.id("newOwn_mlktp")));
			//owner1.selectByVisibleText("Queue");
			
			Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

			String Parent1 = Common.driver.driver.getWindowHandle();

			Set<String> Child1 = Common.driver.driver.getWindowHandles();
			Iterator<String> I1 = Child1.iterator();

			while(I1.hasNext()) {
				
				String Child_actual = I1.next();
				
				if(!Parent1.equals(Child_actual)){
					Common.driver.driver.switchTo().window(Child_actual);
					
					try {
						Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
						Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
						Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
						Common.driver.driver.switchTo().defaultContent();
						
						Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
						Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();
						
					}catch(Exception e){
						e.printStackTrace();
					}
				}
				
			}
			Common.driver.driver.switchTo().window(Parent1);
			

			Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
			Common.driver.driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
			Common.driver.driver.findElement(By.xpath("//a[@href='/secur/logout.jsp']")).click();
			
			
		  
		  Thread.sleep(2000);
			
		  Common.driver.driver.findElement(By.xpath("//input[@id='username']")).sendKeys("divya.suresh@mlecare.co.uk.vmbuat");
		  Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys("Prodapt%3");
		  Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
			
		  Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs007());
			Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
			Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
			
			
			
		  Common.driver.driver.findElement(By.linkText(suborder2)).click();
		  Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[3]")).click();
			
			
			
			

		  
		  
		  //flowtemplate
		  Actions a = new Actions(Common.driver.driver);
		  a.moveToElement(Common.driver.driver.findElement(By.id("CF00N3z00000CWxwn_ileinner"))).
		  doubleClick().build().perform();
		  Common.driver.driver.findElement(By.xpath("//*[@title='Flow Template Lookup (New Window)']/img")).click();
		  Set<String> flow = Common.driver.driver.getWindowHandles(); Iterator<String> itr =
		  flow.iterator(); String parent1= itr.next(); String child1= itr.next();
		  Common.driver.driver.switchTo().window(child1);
		  Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("searchFrame")));
		  Common.driver.driver.findElement(By.id("lksrch")).sendKeys("MAC");
		  Common.driver.driver.findElement(By.name("go")).click();
		  Common.driver.driver.switchTo().defaultContent();
		  Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("resultsFrame")));
		  Common.driver.driver.findElement(By.linkText("MAC_SCW")).click();
		  
		  Common.driver.driver.switchTo().window(parent1);
		  
		  Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[1]")).click();
		  Thread.sleep(1000);

		//roco check case
		Thread.sleep(10000);
		Common.driver.driver.navigate().refresh();
		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//table//tbody/tr[contains(@class,'dataRow')]//td[contains(text(),'ROCO')]//preceding-sibling::th//a")).click();
		Common.driver.driver.findElement(By.xpath("//a[@class='optionItem efpDetailsView ']")).click();
		//additional info
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.name("0663z000002ZXAP")));
		Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:j_id57")).click();
		Select roco = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33")));
		roco.selectByVisibleText("Yes");
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:1:j_id33")).sendKeys("07123765223");
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33")).sendKeys("Test");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:gc1:j_id1:j_id28:j_id29:3:j_id32\"]/span/span")).click();
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:gc1:j_id1:j_id28:j_id36:0:j_id39\"]/span/span/a")).click();
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:gc1:j_id1:j_id28:j_id36:1:j_id39\"]/span/span/a")).click();
		Select welcome = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id36:2:j_id40")));
		welcome.selectByValue("Email");
		Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id58")).click();

		Common.driver.driver.switchTo().defaultContent();
		// closing the case
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
		Select status = new Select(Common.driver.driver.findElement(By.id("cas7")));
		status.selectByValue("Cancelled");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();


		//create billig cases
		
		Thread.sleep(300000);
		Common.driver.driver.navigate().refresh();
		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//table//tbody/tr[contains(@class,'dataRow')]//td[contains(text(),'Create Billing')]//preceding-sibling::th//a")).click();
		Common.driver.driver.findElement(By.xpath("//a[@class='optionItem efpDetailsView ']")).click();
		
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"cas1_ileinner\"]/a[2]")).click();
		Common.driver.driver.findElement(By.xpath("//img[@title='Owner Lookup (New Window)']")).click();
		Set<String> flow1 = Common.driver.driver.getWindowHandles();
		Iterator<String> itr1 = flow1.iterator();
		String parent2 = itr1.next();
		String child2 = itr1.next();
		Common.driver.driver.switchTo().window(child2);
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("resultsFrame")));
		Common.driver.driver.findElement(By.linkText("divya Suresh BCOE")).click();
		Common.driver.driver.switchTo().window(parent2);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		Thread.sleep(1000);
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("0663z000002ZXAP")));
		Thread.sleep(2000);
		
		
		WebElement edit =Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id57"));
		JavascriptExecutor js = (JavascriptExecutor)Common.driver.driver;
		js.executeScript("arguments[0].click()", edit);
		
		Select newcustomer = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:3:j_id33")));
		newcustomer.selectByVisibleText("Yes");

		Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id58")).click();

		Common.driver.driver.switchTo().defaultContent();
		// closing the case
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
		Select status1 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		status1.selectByValue("Cancelled");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();



		Thread.sleep(300000);
		Common.driver.driver.navigate().refresh();
		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//table//tbody/tr[contains(@class,'dataRow')]//td[contains(text(),'Order Third')]//preceding-sibling::th//a")).click();
		Common.driver.driver.findElement(By.xpath("//a[@class='optionItem efpDetailsView ']")).click();
		
		Thread.sleep(2000);
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("0663z000002ZXAP")));
		Thread.sleep(2000);
		
		
		WebElement edit1 =Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id57"));
		JavascriptExecutor js1 = (JavascriptExecutor)Common.driver.driver;
		js1.executeScript("arguments[0].click()", edit1);
		
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33")).sendKeys("Test");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:gc1:j_id1:j_id28:j_id29:1:j_id32\"]/span/span/a")).click();
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33")).sendKeys("Test");
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:7:j_id33")).sendKeys("Test");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:gc1:j_id1:j_id28:j_id36:0:j_id39\"]/span/span/a")).click();
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id36:1:j_id40")).sendKeys("Test");
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id36:4:j_id40")).sendKeys("Test");
		Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id58")).click();

		Common.driver.driver.switchTo().defaultContent();
		// closing the case
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
		Select status2 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		status2.selectByValue("Cancelled");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();
		
		

		Thread.sleep(300000);
		Common.driver.driver.navigate().refresh();
		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//table//tbody/tr[contains(@class,'dataRow')]//td[contains(text(),'Monitor Third')]//preceding-sibling::th//a")).click();
		Common.driver.driver.findElement(By.xpath("//a[@class='optionItem efpDetailsView ']")).click();
		
		Thread.sleep(2000);
		// closing the case
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
				Select status3 = new Select(Common.driver.driver.findElement(By.id("cas7")));
				status3.selectByValue("Cancelled");
				Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
				Thread.sleep(2000);
				Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();
				
		

	// callplantransfer case

		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.name("new_order_workflow_case")).click();
		Select casetype = new Select(Common.driver.driver.findElement(By.id("j_id0:j_id1:pbs1:j_id35:j_id36:j_id37")));
		casetype.selectByVisibleText("Call Plan Transfer");
		
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:j_id1:pbs1:j_id32:bottom\"]/input[1]")).click();
		
		//closing case
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
		Select status4 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		status4.selectByValue("Cancelled");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();
		

		

	//numberport case 

		
		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.name("new_order_workflow_case")).click();
		Select casetype1 = new Select(Common.driver.driver.findElement(By.id("j_id0:j_id1:pbs1:j_id35:j_id36:j_id37")));
		casetype1.selectByVisibleText("Number Port");
		
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:j_id1:pbs1:j_id32:bottom\"]/input[1]")).click();

		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("0663z000002ZXAP")));
		Thread.sleep(2000);
		
		WebElement edit5 =Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id57"));
		JavascriptExecutor js4 = (JavascriptExecutor)Common.driver.driver;
		js4.executeScript("arguments[0].click()", edit5);
		
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33")).sendKeys("porting");
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:1:j_id33")).sendKeys("05877684");
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33")).sendKeys("porting");
		Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id36:0:j_id40")).sendKeys("Test");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:gc1:j_id1:j_id28:j_id36:1:j_id39\"]/span/span/a")).click();
		
		

		Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id58")).click();

		Common.driver.driver.switchTo().defaultContent();
		// closing the case
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
		Select status5 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		status5.selectByValue("Cancelled");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();
		
	// customertraining case

		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.name("new_order_workflow_case")).click();
		Select casetype2 = new Select(Common.driver.driver.findElement(By.id("j_id0:j_id1:pbs1:j_id35:j_id36:j_id37")));
		casetype2.selectByVisibleText("Customer Training");
		
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:j_id1:pbs1:j_id32:bottom\"]/input[1]")).click();
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("0663z000002ZXAP")));
		Thread.sleep(2000);
		
		WebElement edit8 =Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id57"));
		
		js.executeScript("arguments[0].click()", edit8);
		
		Select ct = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33")));
		ct.selectByVisibleText("Yes");
		
		Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id58")).click();

		Common.driver.driver.switchTo().defaultContent();
		// closing the case
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
		
		status.selectByValue("Cancelled");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();
		


	//NGN case

		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.name("new_order_workflow_case")).click();
		Select casetype11 = new Select(Common.driver.driver.findElement(By.id("j_id0:j_id1:pbs1:j_id35:j_id36:j_id37")));
		casetype11.selectByVisibleText("NGN Routing");
		
		Common.driver.driver.findElement(By.xpath("//*[@id=\"j_id0:j_id1:pbs1:j_id32:bottom\"]/input[1]")).click();
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("0663z000002ZXAP")));
		Thread.sleep(2000);
		
		WebElement edit9 =Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id57"));
		
		js.executeScript("arguments[0].click()", edit9);
		
		Select nrc = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33")));//j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33
		nrc.selectByVisibleText("Yes");
		
		Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id58")).click();

		Common.driver.driver.switchTo().defaultContent();
		// closing the case
		Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
		
		status.selectByValue("Cancelled");
		Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
		Thread.sleep(2000);
		Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();

		
	 //completeorder case
		Thread.sleep(10000);
		
		Common.driver.driver.navigate().refresh();
		Common.driver.driver.findElement(By.xpath("//div[@class='listHoverLinks']//span[contains(text(),'Cases')]")).click();
				Thread.sleep(2000);
				Common.driver.driver.findElement(By.xpath("//table//tbody/tr[contains(@class,'dataRow')]//td[contains(text(),'Complete')]//preceding-sibling::th//a")).click();
				Common.driver.driver.findElement(By.xpath("//a[@class='optionItem efpDetailsView ']")).click();
				
				Thread.sleep(2000);
				
				Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.id("0663z000002ZXAP")));
				Thread.sleep(2000);
				
				WebElement edit12 =Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id57"));
				js.executeScript("arguments[0].click()", edit12);
				
				Select close = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33")));//j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33
				close.selectByVisibleText("Email");
				Select CPE = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:1:j_id33")));//j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33
				CPE.selectByVisibleText("No");
				Select remedy = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id36:0:j_id40")));//j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33
				remedy.selectByVisibleText("No");
				Common.driver.driver.findElement(By.name("j_id0:gc1:j_id1:j_id56:bottom:j_id58")).click();

				Common.driver.driver.switchTo().defaultContent();
				
				
				// closing the case
				Common.driver.driver.findElement(By.xpath("//*[@id=\"topButtonRow\"]/input[4]")).click();
						
						status.selectByValue("Cancelled");
						Common.driver.driver.findElement(By.xpath("//*[@id=\"bottomButtonRow\"]/input[1]")).click();
						Thread.sleep(2000);
						Common.driver.driver.findElement(By.xpath("//*[@id=\"lookupaEI8E000000932x00N3z000009SiAz\"]")).click();
	}
	catch(Throwable t) {
		Common.salesforce.teststep.log(Status.FAIL, "failed to cancel 8X8 backoffice product");
		Date today = new Date();
		SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
		String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
		File dir = new File(path1);
		if(!(dir.exists())){
			dir.mkdir();
			
		}
		SimpleDateFormat time = new SimpleDateFormat("hh-mm");
		String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Login_failed_"+time.format(today)+".png";

	   // Call Webdriver to click the screenshot.
	   File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

	   // Save the screenshot.
	   FileUtils.copyFile(scrFile, new File(screenShot));
		
			
		
		
		
		Common.salesforce.teststep.addScreenCaptureFromPath(screenShot);
		//teststep.addScreenCaptureFromPath("path to be provided");
	}
	ExtentReport.extent.flush();




				
	}

}

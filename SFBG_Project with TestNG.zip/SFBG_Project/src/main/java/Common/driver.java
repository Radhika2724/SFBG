package Common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class driver {
	 public static WebDriver driver;
	public static void chromebrowser()
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\radhika.j\\OneDrive\\eclipse\\chromedriver.exe");
		/* Storing the Chrome Profile Path in Chrome_Profile_Path variable. */
		String Chrome_Profile_Path = "C:\\Users\\radhika.j\\AppData\\Local\\Google\\Chrome\\User Data";

		/* Creating an instance of ChromeOptions (i.e objChrome_Profile) */
		ChromeOptions Chrome_Profile = new ChromeOptions();

		/* Disabling the chrome browser extensions */
		Chrome_Profile.addArguments("chrome.switches", "--disable-extensions");
		
		//adding isobars
		Chrome_Profile.addArguments("disable-infobars");

		/* Adding Chrome profile by .addArguments to objChrome_Profile */
		Chrome_Profile.addArguments("--user-data-dir=" + Chrome_Profile_Path);

		/*
		 * Initializing the Webdriver instance (i.e. driver) to open Chrome Browser and
		 * passing the Chrome Profile as argument
		 */
            
		
		driver = new ChromeDriver(Chrome_Profile);
		driver.manage().window().maximize();
		driver.get("https://vmb--vmbuat.my.salesforce.com/");
	}
	
}

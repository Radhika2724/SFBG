package Sfbg;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Excel;
import Common.ExtentReport;

public class TS015_MacNpYes {
	
	@Test(priority=14)
	static void MacNpYes() throws Exception {
			
			Common.salesforce.teststep = ExtentReport.extent.createTest("TS015-MacNpYes");
			Common.driver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));


			
			try {
				
				
				Common.salesforce.teststep.log(Status.PASS, "Order created for mac journey with Numberportingyes");
				Common.Common_functions.logout();
				
				
			 Thread.sleep(2000);
			 Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.Bcoeusername());
			 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
			 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
			 Thread.sleep(2000);
			
			//->****************************************************************************************
			Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs004());
			Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
			Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
			
			

			Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Orders')][1]")).click();
			Common.driver.driver.findElement(By.xpath("//input[@value='New Order']")).click();
			
			Select Supplier = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBC")));
			Supplier.selectByVisibleText("Underlay (FORCE delivered)");
			
			Select Type = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBP")));
			Type.selectByVisibleText("Change (Soft)");
			
			Select PrimaryProd = new Select(Common.driver.driver.findElement(By.id("00N3z000009SiBJ")));
			PrimaryProd.selectByVisibleText("BELS (On-Net)");
			
			Select ProjectMangedOrder = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwj")));
			ProjectMangedOrder.selectByVisibleText("No");
			
			//add billing details
			Common.driver.driver.findElement(By.name("00N3z000009SiB3")).sendKeys("11001");
			
			Select ContractTerm = new Select(Common.driver.driver.findElement(By.id("00N3z00000BpoHu")));
			ContractTerm.selectByVisibleText("3 months");
			
			Select BillingFrequency = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwU")));
			BillingFrequency.selectByVisibleText("Monthly");
			
			Select UnifiedBillingrequired = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxx5")));
			UnifiedBillingrequired.selectByVisibleText("No");
			
			
			Select BillingSystem = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwV")));
			BillingSystem.selectByVisibleText("ICOMS");
			Common.driver.driver.findElement(By.id("CF00N3z000009SiB6")).sendKeys("Janet J");
			Thread.sleep(2000);
	    	Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
		Common.driver.driver.findElement(By.xpath("//input[@name='create_suborders']")).click();
		Thread.sleep(2000);
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@id='iframeContentId']")));
		Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:form1:pb1:j_id28:inputdo']")).sendKeys("1");
		
		Common.driver.driver.findElement(By.name("j_id0:form1:pb1:j_id47:bottom:j_id49")).click();
		
		
		Alert alert = Common.driver.driver.switchTo().alert();
		alert.accept();
		Common.driver.driver.switchTo().defaultContent();
//		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='0663z000002ZXAL']")));
		
		Common.driver.driver.findElement(By.xpath("//div[@class='overlayDialog ']//div[@class='middle']//div[@class='innerContent']//button[text()='Close']")).click();
		Common.driver.driver.navigate().refresh();
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
		
		Common.driver.driver.findElement(By.linkText("Edit")).click();
		
		
	 //address details and Billing
		
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBL']")).sendKeys("Sheffield");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIA']")).sendKeys("GB");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z00000BpoIB']")).sendKeys("United Kingdom");
		Common.driver.driver.findElement(By.xpath("//input[@name='00N3z000009SiBM']")).sendKeys("EC1N 2HT");
		
		Select ContractTerm1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000BpoHu")));
		ContractTerm1.selectByVisibleText("3 months");
		
		Select BillingFrequency1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwU")));
		BillingFrequency1.selectByVisibleText("Monthly");
		
		Select UnifiedBillingrequired1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxx5")));
		UnifiedBillingrequired1.selectByVisibleText("No");
		
		
		Select BillingSystem1 = new Select(Common.driver.driver.findElement(By.id("00N3z00000CWxwV")));
		BillingSystem1.selectByVisibleText("ICOMS");
		
		Common.driver.driver.findElement(By.name("00N3z00000BpoHz")).sendKeys("100.00");
		Common.driver.driver.findElement(By.name("00N3z00000BpoI8")).sendKeys("100.00");
		
		Common.driver.driver.findElement(By.xpath("//input[@value=' Save ']")).click();
		
		Common.driver.driver.findElement(By.xpath("//div[@id='Owner_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();
		//Select owner = new Select(driver.findElement(By.id("newOwn_mlktp")));
		//owner.selectByVisibleText("Queue");
		
		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

		String Parent = Common.driver.driver.getWindowHandle();

		Set<String> Child = Common.driver.driver.getWindowHandles();
		Iterator<String> I = Child.iterator();

		while(I.hasNext()) {
			
			String Child_actual = I.next();
			
			if(!Parent.equals(Child_actual)){
				Common.driver.driver.switchTo().window(Child_actual);
				
				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
					Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
					Common.driver.driver.switchTo().defaultContent();
					
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();
					
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		Common.driver.driver.switchTo().window(Parent);
		

		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();

		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='31']")).click();
		Common.driver.driver.findElement(By.xpath("//div[@class='listRelatedObject Custom21Block']//table[@class='list']//th[@scope='row']")).click();
		Common.driver.driver.findElement(By.xpath("//div[@id='Owner_ileinner']//a[text()[normalize-space(.)= '[Change]']]")).click();
		//Select owner1 = new Select(driver.findElement(By.id("newOwn_mlktp")));
		//owner1.selectByVisibleText("Queue");
		
		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();

		String Parent1 = Common.driver.driver.getWindowHandle();

		Set<String> Child1 = Common.driver.driver.getWindowHandles();
		Iterator<String> I1 = Child1.iterator();

		while(I1.hasNext()) {
			
			String Child_actual = I1.next();
			
			if(!Parent1.equals(Child_actual)){
				Common.driver.driver.switchTo().window(Child_actual);
				
				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					Common.driver.driver.findElement(By.id("lksrch")).sendKeys("divya Suresh MLE Care");
					Common.driver.driver.findElement(By.xpath("//input[@name='go']")).click();
					Common.driver.driver.switchTo().defaultContent();
					
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//a[@href='#']")).click();
					
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		Common.driver.driver.switchTo().window(Parent1);
		

		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		Common.driver.driver.findElement(By.xpath("//a[@href='javascript:void(0)']")).click();
		Common.driver.driver.findElement(By.xpath("//a[@href='/secur/logout.jsp']")).click();
		
		Thread.sleep(2000);
		
		

		Common.driver.driver.findElement(By.id("username")).sendKeys("divya.suresh@mlecare.co.uk.vmbuat");
		Common.driver.driver.findElement(By.id("password")).sendKeys("Prodapt%3");
		Common.driver.driver.findElement(By.id("Login")).click();
		//Common.driver.driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		Thread.sleep(2000);
		
		
		
		//->*****************************************************************************************
		//->****************************************************************************************
				Common.driver.driver.findElement(By.xpath("//input[@name='str']")).sendKeys(Excel.opportunityTs004());
				Common.driver.driver.findElement(By.xpath("//input[@value='Search']")).click();
				Common.driver.driver.findElement(By.xpath("//table[@class='list']//th[@scope='row']//a[@data-seclke='Opportunity']")).click();
		
		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Orders')][1]")).click();
		
		Common.driver.driver.findElement(By.xpath("//div[@class='listRelatedObject Custom21Block']//table[@class='list']//th[@scope='row']")).click();
		
		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Orders (Sub Order)')]")).click();
		
		/*
		driver.findElement(By.xpath("//a[@class='actionLink']")).click();
		
		WebElement flowtemplate = driver.findElement(By.xpath("//a[@id='CF00N3z00000CWxwn_lkwgt']"));
		flowtemplate.click();
		
		String Parent = driver.getWindowHandle();

		Set<String> Child = driver.getWindowHandles();
		Iterator<String> I = Child.iterator();

		while(I.hasNext()) {
			
			String Child_actual = I.next();
			
			if(!Parent.equals(Child_actual)){
				driver.switchTo().window(Child_actual);
				
				try {
					driver.switchTo().frame(driver.findElement(By.xpath("//frame[@name='searchFrame']")));
					driver.findElement(By.id("lksrch")).sendKeys("MAC_DirectVoice");
					driver.findElement(By.xpath("//input[@name='go']")).click();
					driver.switchTo().defaultContent();
					
					driver.switchTo().frame(driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					driver.findElement(By.xpath("//a[@href='#']")).click();
					
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		driver.switchTo().window(Parent);
		
		driver.findElement(By.xpath("//input[@name='save']")).click(); 
		
		*/
		Common.driver.driver.findElement(By.xpath("//div[@class='listRelatedObject Custom21Block']//table[@class='list']//th[@scope='row']")).click();
			 
		
		Common.driver.driver.navigate().refresh();
		Thread.sleep(100000);
		Common.driver.driver.navigate().refresh();
		//driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='32']//span[@class='listTitle']")).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Data Capture')]//preceding-sibling::th//a")));
		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Data Capture')]//preceding-sibling::th//a")).click();
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[text()[normalize-space(.)= '[Change]']]")).click();
		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();
	    String parent = Common.driver.driver.getWindowHandle();
		
		Set<String> child = Common.driver.driver.getWindowHandles();
		Iterator<String> i = child.iterator();
		
		while(i.hasNext()) {
			
			String child_actual = i.next();
			
			if(!parent.equals(child_actual)){
				Common.driver.driver.switchTo().window(child_actual);
				Common.driver.driver.manage().window().fullscreen();
				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//div[@class='pbBody']//table//a[contains(text(),'divya Suresh MLE Care')]")).click();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		
		Common.driver.driver.switchTo().window(parent);
		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();
		

		Select CaseStatus = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus.selectByVisibleText("Completed");
		
		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();

		Common.driver.driver.navigate().refresh();
		Thread.sleep(300000);
		Common.driver.driver.navigate().refresh();
		//driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='32']//span[@class='listTitle']")).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Initiate Order')]//preceding-sibling::th//a")));
		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Initiate Order')]//preceding-sibling::th//a")).click();
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@name='0663z000002ZXAP']")));
		Common.driver.driver.findElement(By.xpath("//td[@class='pbButton ']//input[@value='Edit']")).click();
		
		//*****************************ADDITIONAL INFORMATION**********************
		
		Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33']")).sendKeys("W011");
		
		Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:gc1:j_id1:j_id28:j_id29:1:j_id33']")).sendKeys("Site01");
		
		Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:gc1:j_id1:j_id28:j_id36:0:j_id40']")).sendKeys("100900988");
		
		Select NumberPorting = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:2:j_id33")));
		NumberPorting.selectByVisibleText("Yes");
		
		Common.driver.driver.findElement(By.xpath("//textarea[@id='j_id0:gc1:j_id1:j_id28:j_id36:1:j_id40']")).sendKeys("Test Initiate");
		
		
		Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:gc1:j_id1:j_id56:j_id58']")).click();
		
		Common.driver.driver.switchTo().defaultContent();
		
		
		
		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();
		

		Select CaseStatus1 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus1.selectByVisibleText("Completed");
		
		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();
		
		Common.driver.driver.navigate().refresh();
		Thread.sleep(360000);
		Common.driver.driver.navigate().refresh();
		//driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='32']//span[@class='listTitle']")).click();
		
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Number Port')]//preceding-sibling::th//a")));
		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Number Port')]//preceding-sibling::th//a")).click();
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@name='0663z000002ZXAP']")));
		Common.driver.driver.findElement(By.xpath("//td[@class='pbButton ']//input[@value='Edit']")).click();
		
		//*****************************ADDITIONAL INFORMATION**********************
		
		WebElement PlannedPortdate = Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:gc1:j_id1:j_id28:j_id36:0:j_id40']"));
		PlannedPortdate.click();
		Common.driver.driver.findElement(By.xpath("//a[@class='calToday']")).click();
		
		
		Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:gc1:j_id1:j_id56:j_id58']")).click();
		
		Common.driver.driver.switchTo().defaultContent();
		
		Common.driver.driver.findElement(By.xpath("//a[text()[normalize-space(.)= '[Change]']]")).click();
		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();
	    String parent2 = Common.driver.driver.getWindowHandle();
		
		Set<String> child2 = Common.driver.driver.getWindowHandles();
		Iterator<String> i1 = child2.iterator();
		
		while(i1.hasNext()) {
			
			String child_actual = i1.next();
			
			if(!parent2.equals(child_actual)){
				Common.driver.driver.switchTo().window(child_actual);
				Common.driver.driver.manage().window().fullscreen();
				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//div[@class='pbBody']//table//a[contains(text(),'divya Suresh MLE Care')]")).click();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		
		Common.driver.driver.switchTo().window(parent2);
		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();
		

		Select CaseStatus2 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus2.selectByVisibleText("Completed");
		
		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();

		Common.driver.driver.navigate().refresh();
		Thread.sleep(360000);
		Common.driver.driver.navigate().refresh();
		//driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='32']//span[@class='listTitle']")).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Confirm Order')]//preceding-sibling::th//a")));
		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Confirm Order')]//preceding-sibling::th//a")).click();
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@name='0663z000002ZXAP']")));
		Common.driver.driver.findElement(By.xpath("//td[@class='pbButton ']//input[@value='Edit']")).click();
		
		//*****************************ADDITIONAL INFORMATION**************************************************
		
		Select portDateaccepted = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33")));
		portDateaccepted.selectByVisibleText("Yes");
		
		
		Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:gc1:j_id1:j_id56:j_id58']")).click();
		
		Common.driver.driver.switchTo().defaultContent();
		
		
		
		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();
		

		Select CaseStatus3 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus3.selectByVisibleText("Completed");
		
		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();

		Common.driver.driver.navigate().refresh();
		Thread.sleep(480000);
		Common.driver.driver.navigate().refresh();
		//driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='32']//span[@class='listTitle']")).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Datafill')]//preceding-sibling::th//a")));
		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Datafill')]//preceding-sibling::th//a")).click();
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@name='0663z000002ZXAP']")));
		Common.driver.driver.findElement(By.xpath("//td[@class='pbButton ']//input[@value='Edit']")).click();
		
		//*****************************ADDITIONAL INFORMATION**************************************************
		
		
		Select Datefillstage = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33")));
		Datefillstage.selectByVisibleText("Complete");
		
		WebElement CustomerExecuteday = Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:gc1:j_id1:j_id28:j_id36:0:j_id40']"));
		CustomerExecuteday.click();
		Common.driver.driver.findElement(By.xpath("//a[@class='calToday']")).click();
		
		Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:gc1:j_id1:j_id56:j_id58']")).click();
		
		Common.driver.driver.switchTo().defaultContent();
		
		Common.driver.driver.findElement(By.xpath("//a[text()[normalize-space(.)= '[Change]']]")).click();
		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();
	    String parent4 = Common.driver.driver.getWindowHandle();
		
		Set<String> child4 = Common.driver.driver.getWindowHandles();
		Iterator<String> i4 = child4.iterator();
		
		while(i4.hasNext()) {
			
			String child_actual = i4.next();
			
			if(!parent4.equals(child_actual)){
				Common.driver.driver.switchTo().window(child_actual);
				Common.driver.driver.manage().window().fullscreen();
				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//div[@class='pbBody']//table//a[contains(text(),'divya Suresh MLE Care')]")).click();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		
		Common.driver.driver.switchTo().window(parent4);
		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();
		

		Select CaseStatus4 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus4.selectByVisibleText("Completed");
		
		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();

		Common.driver.driver.navigate().refresh();
		Thread.sleep(60000);
		Common.driver.driver.navigate().refresh();
		
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='32']//span[@class='listTitle']")).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Complete Order')]//preceding-sibling::th//a")));
		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Complete Order')]//preceding-sibling::th//a")).click();
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@name='0663z000002ZXAP']")));
		Common.driver.driver.findElement(By.xpath("//td[@class='pbButton ']//input[@value='Edit']")).click();
		
		//*****************************ADDITIONAL INFORMATION**************************************************

		Select CloseType = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33")));
		CloseType.selectByVisibleText("Email");
		
		
		Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:gc1:j_id1:j_id56:j_id58']")).click();
		
		Common.driver.driver.switchTo().defaultContent();
		
		
		
		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();
		

		Select CaseStatus5 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus5.selectByVisibleText("Completed");
		
		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();
		
		Common.driver.driver.navigate().refresh();
		Thread.sleep(360000);
		Common.driver.driver.navigate().refresh();
		
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='32']//span[@class='listTitle']")).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Check Order')]//preceding-sibling::th//a")));
		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Check Order')]//preceding-sibling::th//a")).click();
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		
		Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//iframe[@name='0663z000002ZXAP']")));
		Common.driver.driver.findElement(By.xpath("//td[@class='pbButton ']//input[@value='Edit']")).click();
		

		//*****************************ADDITIONAL INFORMATION**************************************************

		Select BT999DACPChecked = new Select(Common.driver.driver.findElement(By.id("j_id0:gc1:j_id1:j_id28:j_id29:0:j_id33")));
		BT999DACPChecked.selectByVisibleText("Yes");
		
		
		Common.driver.driver.findElement(By.xpath("//input[@name='j_id0:gc1:j_id1:j_id56:j_id58']")).click();
		
		Common.driver.driver.switchTo().defaultContent();
		
		
		
		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();
		

		Select casestatus6 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		casestatus6.selectByVisibleText("Completed");
		
		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();

		Common.driver.driver.navigate().refresh();
		Thread.sleep(540000);
		Common.driver.driver.navigate().refresh();
		
		Common.driver.driver.findElement(By.xpath("//a[@data-uidsfdc='32']//span[@class='listTitle']")).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Billing Trigger')]//preceding-sibling::th//a")));
		Common.driver.driver.findElement(By.xpath("//table/tbody/tr[contains(@class,'dataRow')]/td[contains(text(),'Billing Trigger')]//preceding-sibling::th//a")).click();
		

		Common.driver.driver.findElement(By.xpath("//span[contains(text(),'Details')]")).click();
		Common.driver.driver.findElement(By.xpath("//a[text()[normalize-space(.)= '[Change]']]")).click();
		Common.driver.driver.findElement(By.xpath("//*[contains(@class,'lookupIcon')]")).click();
	    String parent7 = Common.driver.driver.getWindowHandle();
		
		Set<String> child7 = Common.driver.driver.getWindowHandles();
		Iterator<String> i7 = child7.iterator();
		
		while(i7.hasNext()) {
			
			String child_actual = i7.next();
			
			if(!parent7.equals(child_actual)){
				Common.driver.driver.switchTo().window(child_actual);
				Common.driver.driver.manage().window().fullscreen();
				try {
					Common.driver.driver.switchTo().frame(Common.driver.driver.findElement(By.xpath("//frame[@id='resultsFrame']")));
					Common.driver.driver.findElement(By.xpath("//div[@class='pbBody']//table//a[contains(text(),'divya Suresh MLE Care')]")).click();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			
		}
		
		Common.driver.driver.switchTo().window(parent7);
		Common.driver.driver.findElement(By.xpath("//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@title='Close Case']")).click();
		

		Select CaseStatus8 = new Select(Common.driver.driver.findElement(By.id("cas7")));
		CaseStatus8.selectByVisibleText("Completed");
		
		Common.driver.driver.findElement(By.xpath("//div[@class='pbHeader']//td[@class='pbButton']//input[@name='save']")).click();
		
		Common.driver.driver.findElement(By.xpath("//a[contains(text(),'SO-')]")).click();
		}
		catch(Throwable t) {
			Common.salesforce.teststep.log(Status.FAIL, "Order created for mac journey with Numberportingyes");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Login_failed_"+time.format(today)+".png";

		    // Call Webdriver to click the screenshot.
		    File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

		    // Save the screenshot.
		    FileUtils.copyFile(scrFile, new File(screenShot));
			
				
			
			
			
			Common.salesforce.teststep.addScreenCaptureFromPath(screenShot);
			//teststep.addScreenCaptureFromPath("path to be provided");
		}
		ExtentReport.extent.flush();

		
		return;
		
	}

}

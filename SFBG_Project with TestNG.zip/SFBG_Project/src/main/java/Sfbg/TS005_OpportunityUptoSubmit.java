package Sfbg;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Excel;
import Common.ExtentReport;

public class TS005_OpportunityUptoSubmit {
	@Test(priority=4)
	public static void submit() throws IOException
	{
		Common.salesforce.teststep = ExtentReport.extent.createTest("TS005-Opportunity upto Submit stage");
		Common.driver.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));


		
		try {
			
			
			Common.salesforce.teststep.log(Status.PASS, "Opportunity moved upto Submit stage");
			
			Common.Common_functions.logout();
			Thread.sleep(3000);
			//login to salesforce
			
			Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.salesdeskusername());
			 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
			 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
		     Thread.sleep(5000);
			
		
		     //Creating new opportunity
		     
				Common.driver.driver.findElement(By.xpath("//a[@title='Opportunities Tab']")).click();
				
				Common.driver.driver.findElement(By.name("new")).click();
				 
				Common.driver.driver.findElement(By.id("opp3")).sendKeys(Excel.opportunityTs005());
				 
				Common.driver.driver.findElement(By.id("opp4")).sendKeys("test.janet");
				 
				 WebElement type = Common.driver.driver.findElement(By.id("opp5"));
				 Select a = new Select(type);
				 a.selectByValue("New");
				 
				 WebElement typedetails = Common.driver.driver.findElement(By.id("00Nb00000039oS4"));
				 Select td = new Select(typedetails);
				 td.selectByValue("New Business");
				 
				 WebElement sales= Common.driver.driver.findElement(By.id("00Nb00000039oS1"));
				 Select b = new Select(sales);
				 b.selectByValue("Telesales");
				 
				 WebElement FA = Common.driver.driver.findElement(By.id("00Nb0000006MHJ7"));
				 Select c = new Select (FA);
				 c.selectByValue("No");
				 
				WebElement productintrest = Common.driver.driver.findElement(By.id("00Nb00000039p5N"));
				Select d = new Select(productintrest);
				d.selectByValue("Broadband");
				
				Common.driver.driver.findElement(By.xpath("//*//table[@id='bodyTable']//tbody//tr//td[2]//form//table[@class='detailList']//tbody//tr//td[4]//div[1]//span//span[@class='dateFormat']//a")).click();
				WebElement stage = Common.driver.driver.findElement(By.id("opp11"));
				Select e = new Select(stage);
				e.selectByValue("Qualified");
				
				WebElement pm = Common.driver.driver.findElement(By.id("00N3z00000CWxyX"));
				Select f = new Select(pm);
				f.selectByValue("No");
				
				Common.driver.driver.findElement(By.id("opp17")).sendKeys("test");
				
				Common.driver.driver.findElement(By.xpath("//input[@value='Save & Add Product']")).click();
				//adding the products
				Common.driver.driver.findElement(By.id("j_id0:all:j_id41:searchbox")).sendKeys(Excel.product());
				Common.driver.driver.findElement(By.name("j_id0:all:j_id41:search_button")).click();
				Thread.sleep(4000);
				
				Common.driver.driver.findElement(By.xpath("//table[@id='prodTable']//tr[1]//td[1]")).click();
				Thread.sleep(2000);
				
				
				
				 WebElement bpt = Common.driver.driver.findElement(By.name("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id109"));
			      Select bp = new Select (bpt);
			      bp.selectByValue("No");
				
			      Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id115")).sendKeys("1");
				
				//dates
				WebElement date =Common.driver.driver.findElement(By.xpath("//tbody/tr[13]/td[1]/div[1]/span[1]/span[1]/a[1]"));
				  JavascriptExecutor js = (JavascriptExecutor)Common.driver.driver;
				   	js.executeScript("arguments[0].click()", date);
				Thread.sleep(2000);
			   WebElement ele =Common.driver.driver.findElement(By.xpath("//tbody/tr[14]/td[1]/span[1]/span[1]/a[1]"));
			      
			  	js.executeScript("arguments[0].click()", ele);
			      
			      Thread.sleep(2000);
			     
			    WebElement ele1=  Common.driver.driver.findElement(By.xpath("//tbody/tr[15]/td[1]/span[1]/span[1]/a[1]"));
			    
				js.executeScript("arguments[0].click()", ele1);
				Thread.sleep(2000);
				WebElement billing = Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id137"));
				Select bill = new Select (billing);
				bill.selectByValue("Monthly");
				   Thread.sleep(1000);                                          //j_id0:all:selectedproducts:j_id94:0:j_id96:j_id100
				 WebElement type1 = Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id100"));
				 Select ab = new Select(type1);
				 ab.selectByValue("New");
				 Thread.sleep(1000);
				 
				 WebElement typedetails1 = Common.driver.driver.findElement(By.id("j_id0:all:selectedproducts:j_id94:0:j_id96:j_id101"));
				 Select td1 = new Select(typedetails1);
				 td1.selectByValue("New Business");
				 
				 Thread.sleep(3000);
				 Common.driver.driver.findElement(By.xpath("//input[@id='j_id0:all:selectedproducts:j_id90:saveComeBack']")).click(); 
				 Thread.sleep(3000);
				 Common.Common_functions.logout();
				 //login to BCOE
				 Thread.sleep(2000);
				 Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.Bcoeusername());
				 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
				 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
				 
				 //checking the quoting autoapproval check box
				 Common.driver.driver.findElement(By.xpath("//input[@id='phSearchInput']")).sendKeys(Excel.opportunityTs005());
				 Common.driver.driver.findElement(By.id("phSearchButton")).click();
				 Common.driver.driver.findElement(By.linkText(Excel.opportunityTs005())).click();
				 Thread.sleep(5000);
				 Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='edit']")).click();
				 Thread.sleep(1000);
				 Common.driver.driver.findElement(By.id("00Nb000000ADKJ5")).click();
			     
				 Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='save']")).click();
				 Thread.sleep(2000);
				 Common.Common_functions.logout();
				 Thread.sleep(3000);
				
				 //login to salesforce
				 Common.driver.driver.findElement(By.id("username")).sendKeys(Excel.salesdeskusername());
				 Common.driver.driver.findElement(By.cssSelector("input#password")).sendKeys(Excel.pwd());
				 Common.driver.driver.findElement(By.xpath("//input[@type='submit']")).click();
			     Thread.sleep(4000);
			     Common.driver.driver.findElement(By.xpath("//input[@id='phSearchInput']")).sendKeys(Excel.opportunityTs005());
				 Common.driver.driver.findElement(By.id("phSearchButton")).click();
				 Common.driver.driver.findElement(By.linkText(Excel.opportunityTs005())).click();
			     //stage moved upto quoted
			     Thread.sleep(2000);
			     Common.driver.driver.findElement(By.name("submit")).click();
			     Common.driver.driver.switchTo().alert().accept();
				Thread.sleep(2000);
				
				//stage moved to awaiting 
				Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='edit']")).click();
				Select stage11= new Select(Common.driver.driver.findElement(By.id("opp11")));
				stage11.selectByValue("Awaiting Contract");
				Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='save']")).click();
				Thread.sleep(2000);
				 WebElement frame1 = Common.driver.driver.findElement(By.xpath("//iframe[@id='066b0000001NDxa']"));
				 Common.driver.driver.switchTo().frame(frame1);
				 //adding document name and link
				WebElement docname= Common.driver.driver.findElement(By.id("j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_1_j_id11_ilecell"));
				Actions doc = new Actions(Common.driver.driver);
				doc.moveToElement(docname).doubleClick().build().perform();
				Thread.sleep(1000);
				Common.driver.driver.findElement(By.id("j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_1_j_id11")).sendKeys("abc");
				
				WebElement doclink =  Common.driver.driver.findElement(By.id("j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11_ilecell"));
			   Actions doc1 = new Actions(Common.driver.driver);
			   doc1.moveToElement(doclink).doubleClick().build().perform();
			   Thread.sleep(1000);
			  // id="j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11_ilecell" j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11
			   Common.driver.driver.findElement(By.id("j_id0_j_id1_j_id3_j_id6_j_id7_j_id8_0_j_id9_2_j_id11")).sendKeys("abc.com");
			   Common.driver.driver.findElement(By.name("j_id0:j_id1:j_id3:j_id4:bottom:j_id5")).click();

			   
			   Common.driver.driver.switchTo().defaultContent();
				WebElement payplan = Common.driver.driver.findElement(By.id("00Nb0000003s0T7_chkbox"));
				Actions pp = new Actions (Common.driver.driver);
				pp.moveToElement(payplan).doubleClick().build().perform();
				Common.driver.driver.findElement(By.id("00Nb0000003s0T7")).click();
				Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='inlineEditSave']")).click();
				
				
				Thread.sleep(5000);
				//stage moved to submit
				Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='edit']")).click();
				Thread.sleep(1000);
				Select s = new Select(Common.driver.driver.findElement(By.id("opp11")));
				s.selectByVisibleText("Submit Contract");
				Common.driver.driver.findElement(By.xpath("//td[@id='topButtonRow']//input[@name='save']")).click();
				Thread.sleep(2000);
				
		}catch(Throwable t) {
			Common.salesforce.teststep.log(Status.FAIL,"Failed to move to Submit stage");
			Date today = new Date();
			SimpleDateFormat dateformat =new SimpleDateFormat("dd-MM-yyyy");
			String path1 = (System.getProperty("user.dir")+"\\Screenshot of login"+dateformat.format(today));
			File dir = new File(path1);
			if(!(dir.exists())){
				dir.mkdir();
				
			}
			SimpleDateFormat time = new SimpleDateFormat("hh-mm");
			String screenShot = System.getProperty("user.dir")+"\\Screenshots of failed cases\\"+dateformat.format(today)+"\\Error in submit stage"+time.format(today)+".png";

	        // Call Webdriver to click the screenshot.
	        File scrFile = ((TakesScreenshot) Common.driver.driver).getScreenshotAs(OutputType.FILE);

	        // Save the screenshot.
	        FileUtils.copyFile(scrFile, new File(screenShot));
			
			
		}
		ExtentReport.extent.flush();
				
	}


}
